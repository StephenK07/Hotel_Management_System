package com.hms.reservation.exception;

public class NoIdExistsException extends RuntimeException {

	public NoIdExistsException(String msg) {
		super(msg);
	}

}
