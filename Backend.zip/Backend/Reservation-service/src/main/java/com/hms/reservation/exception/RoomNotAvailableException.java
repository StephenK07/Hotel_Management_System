package com.hms.reservation.exception;

public class RoomNotAvailableException extends Exception {
	
	public RoomNotAvailableException(String msg) {
		super(msg);
	}

}
