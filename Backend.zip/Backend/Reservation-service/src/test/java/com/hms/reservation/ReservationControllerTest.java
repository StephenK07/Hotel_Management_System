package com.hms.reservation;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hms.reservation.controller.ReservationController;
import com.hms.reservation.entity.Reservation;
import com.hms.reservation.exception.RoomNotAvailableException;
import com.hms.reservation.service.ReservationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.util.List;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@SpringBootTest
public class ReservationControllerTest {

    @InjectMocks
    private ReservationController reservationController;

    @Mock
    private ReservationServiceImpl reservationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddReservation_Success() throws RoomNotAvailableException {
        Reservation reservation = new Reservation();

        when(reservationService.addReservation(reservation)).thenReturn("Reservation added successfully");

        ResponseEntity<String> responseEntity = reservationController.addReservation(reservation);

        assertEquals("Reservation added successfully", responseEntity.getBody());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        verify(reservationService, times(1)).addReservation(reservation);
    }

    @Test
    void testAddReservation_RoomNotAvailable() throws RoomNotAvailableException {
        Reservation reservation = new Reservation();

        when(reservationService.addReservation(reservation)).thenThrow(RoomNotAvailableException.class);

        assertThrows(RoomNotAvailableException.class, () -> {
            reservationController.addReservation(reservation);
        });

        verify(reservationService, times(1)).addReservation(reservation);
    }

    @Test
    void testUpdateReservation_Success() {
        String reservationId = "1";
        Reservation updatedReservation = new Reservation();

        when(reservationService.updateReservation(reservationId, updatedReservation)).thenReturn("Reservation updated successfully");

        ResponseEntity<String> responseEntity = reservationController.updateReservation(reservationId, updatedReservation);

        assertEquals("Reservation updated successfully", responseEntity.getBody());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        verify(reservationService, times(1)).updateReservation(reservationId, updatedReservation);
    }

    @Test
    void testDeleteReservation_Success() {
        String reservationId = "1";

        when(reservationService.deleteReservation(reservationId)).thenReturn("Reservation deleted successfully");

        ResponseEntity<String> responseEntity = reservationController.deleteReservation(reservationId);

        assertEquals("Reservation deleted successfully", responseEntity.getBody());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        verify(reservationService, times(1)).deleteReservation(reservationId);
    }

    @Test
    void testViewReservation_Success() throws RoomNotAvailableException {
        String reservationId = "1";
        Reservation reservation = new Reservation();

        when(reservationService.viewReservation(reservationId)).thenReturn(reservation);

        ResponseEntity<Reservation> responseEntity = reservationController.viewReservation(reservationId);

        assertEquals(reservation, responseEntity.getBody());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        verify(reservationService, times(1)).viewReservation(reservationId);
    }

    @Test
    void testViewAllReservation_Success() {
        List<Reservation> reservations = new ArrayList<>();
        reservations.add(new Reservation());
        reservations.add(new Reservation());

        when(reservationService.viewAllReservation()).thenReturn(reservations);

        ResponseEntity<List<Reservation>> responseEntity = reservationController.viewAllReservation();

        assertEquals(reservations, responseEntity.getBody());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        verify(reservationService, times(1)).viewAllReservation();
    }
}
