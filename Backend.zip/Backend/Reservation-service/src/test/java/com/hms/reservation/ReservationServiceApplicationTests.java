package com.hms.reservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

	import org.junit.jupiter.api.BeforeEach;
	import org.junit.jupiter.api.Test;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.Mockito;
	import org.mockito.MockitoAnnotations;
	import org.springframework.web.client.RestTemplate;
	import java.time.LocalDate;
	import java.util.Optional;
	import java.time.format.DateTimeFormatter;
	import java.util.List;

	import static org.junit.jupiter.api.Assertions.*;
	import com.hms.guest.entity.Guest;
	import com.hms.guest.exceptions.NoIdExistsException;
	import com.hms.reservation.entity.Reservation;
	import com.hms.reservation.entity.Room;
	import com.hms.reservation.exception.RoomNotAvailableException;
	import com.hms.reservation.repository.ReservationRepository;
	import com.hms.reservation.service.ReservationServiceImpl;
    
	@SpringBootTest
	public class ReservationServiceApplicationTests {

	    @InjectMocks
	    private ReservationServiceImpl reservationService;

	    @Mock
	    private ReservationRepository reservationRepository;

	    @Mock
	    private RestTemplate restTemplate;

	    @BeforeEach
	    void setUp() {
	        MockitoAnnotations.openMocks(this);
	    }

	    @Test
	    void testAddReservation_Success() throws RoomNotAvailableException {
	        Reservation reservation = new Reservation();
	        Room room = new Room("1", 0, "true", 100, null);

	        Guest guest = new Guest("John Doe", "john@example.com", "1234567890", "Male", "123 Main St", null);

	        Mockito.when(restTemplate.getForObject("http://localhost:8081/room/viewroom/1", Room.class)).thenReturn(room);
	        Mockito.when(restTemplate.getForObject("http://localhost:8080/guest/viewguest/1", Guest.class)).thenReturn(guest);
	        Mockito.when(reservationRepository.save(reservation)).thenReturn(reservation);

	        String result = reservationService.addReservation(reservation);

	        assertEquals("Room number 1 is booked for 'John Doe'. Total price: $200", result);
	    }

	    @Test
	    void testAddReservation_RoomNotAvailable() {
	        Reservation reservation = new Reservation();
	        Room room = new Room("1", 0, "false", 100, null);

	        Mockito.when(restTemplate.getForObject("http://localhost:8081/room/viewroom/1", Room.class)).thenReturn(room);

	        assertThrows(RoomNotAvailableException.class, () -> {
	            reservationService.addReservation(reservation);
	        });
	    }

	    @Test
	    void testUpdateReservation_Success() {
	        String reservationId = "1";
	        Reservation existingReservation = new Reservation();
	        Reservation updatedReservation = new Reservation();
	        Room room = new Room("2", 0, "true", 150, reservationId);

	        Mockito.when(restTemplate.getForObject("http://localhost:8081/room/viewroom/2", Room.class)).thenReturn(room);
	        Mockito.when(reservationRepository.findByReservationId(reservationId)).thenReturn(existingReservation);
	        Mockito.when(reservationRepository.save(existingReservation)).thenReturn(existingReservation);

	        String result = reservationService.updateReservation(reservationId, updatedReservation);

	        assertEquals("Reservation updated successfully. Total price updated to $300", result);
	    }

	    @Test
	    void testUpdateReservation_RoomNotAvailable() {
	        String reservationId = "1";
	        Reservation existingReservation = new Reservation();
	        Reservation updatedReservation = new Reservation();
	        Room room = new Room("2", 0, "false", 150, reservationId);

	        Mockito.when(restTemplate.getForObject("http://localhost:8081/room/viewroom/2", Room.class)).thenReturn(room);
	        Mockito.when(reservationRepository.findByReservationId(reservationId)).thenReturn(existingReservation);

	        assertThrows(RoomNotAvailableException.class, () -> {
	            reservationService.updateReservation(reservationId, updatedReservation);
	        });
	    }

	    @Test
	    void testViewReservation_Success() {
	        String reservationId = "1";
	        Reservation existingReservation = new Reservation();

	        Mockito.when(reservationRepository.findByReservationId(reservationId)).thenReturn(existingReservation);

	        Reservation result = reservationService.viewReservation(reservationId);

	        assertEquals(existingReservation, result);
	    }

	    @Test
	    void testViewReservation_NoIdExists() {
	        String reservationId = "1";

	        Mockito.when(reservationRepository.findByReservationId(reservationId)).thenReturn(null);

	        assertThrows(NoIdExistsException.class, () -> {
	            reservationService.viewReservation(reservationId);
	        });
	    }

	    @Test
	    void testViewAllReservation() {
	        List<Reservation> reservations = List.of(
	            new Reservation(),
	            new Reservation()
	        );

	        Mockito.when(reservationRepository.findAll()).thenReturn(reservations);

	        List<Reservation> result = reservationService.viewAllReservation();

	        assertEquals(reservations, result);
	    }
	}
