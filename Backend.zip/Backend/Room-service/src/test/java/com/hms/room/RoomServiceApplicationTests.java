package com.hms.room;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.hms.room.entity.Room;
import com.hms.room.exceptions.RoomAlreadyExistsException;
import com.hms.room.exceptions.RoomNotFoundException;
import com.hms.room.repository.RoomRepository;
import com.hms.room.service.RoomServiceImpl;

@SpringBootTest
public class RoomServiceApplicationTests {


    @InjectMocks
    private RoomServiceImpl roomService;

    @Mock
    private RoomRepository roomRepository;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testAddRoom_Success() {
        // Create a room
        Room room = new Room(null, 101, "Standard", 2500, "true");
        Mockito.when(roomRepository.findByRoomNo(101)).thenReturn(null);
        Mockito.when(roomRepository.save(room)).thenReturn(room);

        String result = roomService.addRoom(room);
        assertEquals("Room added successfully", result);
    }

    @Test
    public void testAddRoom_RoomAlreadyExists() {
        // Attempt to add a room with a duplicate room number
        Room room = new Room(null, 101, "Deluxe", 3000, "false");
        Mockito.when(roomRepository.findByRoomNo(101)).thenReturn(room);

        assertThrows(RoomAlreadyExistsException.class, () -> {
            roomService.addRoom(room);
        });
    }

    @Test
    public void testUpdateRoom_Success() throws RoomNotFoundException {
        // Update an existing room
        int roomNo = 101;
        Room roomToUpdate = new Room(null, roomNo, "Deluxe", 3000, "false");
        Room existingRoom = new Room(null, roomNo, "Standard", 2500, "true");

        Mockito.when(roomRepository.findByRoomNo(roomNo)).thenReturn(existingRoom);
        Mockito.when(roomRepository.save(existingRoom)).thenReturn(roomToUpdate);

        Room updatedRoom = roomService.updateRoom(roomNo, roomToUpdate);
        assertEquals(roomToUpdate, updatedRoom);
    }

    @Test
    public void testUpdateRoom_RoomNotFound() {
        // Attempt to update a room that does not exist
        int roomNo = 101;
        Room roomToUpdate = new Room(null, roomNo, "Deluxe", 3000, "false");
        Mockito.when(roomRepository.findByRoomNo(roomNo)).thenReturn(null);

        assertThrows(RoomNotFoundException.class, () -> {
            roomService.updateRoom(roomNo, roomToUpdate);
        });
    }

    @Test
    public void testDeleteRoom_Success() throws RoomNotFoundException {
        // Delete an existing room
        int roomNo = 101;
        Room roomToDelete = new Room(null, roomNo, "Standard", 2500, "true");
        Mockito.when(roomRepository.findByRoomNo(roomNo)).thenReturn(roomToDelete);

        String result = roomService.deleteRoom(roomNo);
        assertEquals("Room Deleted successfully!!", result);
    }

    @Test
    public void testDeleteRoom_RoomNotFound() {
        // Attempt to delete a room that does not exist
        int roomNo = 101;
        Mockito.when(roomRepository.findByRoomNo(roomNo)).thenReturn(null);

        assertThrows(RoomNotFoundException.class, () -> {
            roomService.deleteRoom(roomNo);
        });
    }

    @Test
    public void testViewRoom_Success() throws RoomNotFoundException {
        // View an existing room
        int roomNo = 101;
        Room roomToView = new Room(null, roomNo, "Standard", 2500, "true");
        Mockito.when(roomRepository.findByRoomNo(roomNo)).thenReturn(roomToView);

        Room viewedRoom = roomService.viewRoom(roomNo);
        assertEquals(roomToView, viewedRoom);
    }

    @Test
    public void testViewRoom_RoomNotFound() {
        // Attempt to view a room that does not exist
        int roomNo = 101;
        Mockito.when(roomRepository.findByRoomNo(roomNo)).thenReturn(null);

        assertThrows(RoomNotFoundException.class, () -> {
            roomService.viewRoom(roomNo);
        });
    }

    @Test
    public void testViewAllAvailable() {
        // Retrieve a list of available rooms
        List<Room> rooms = new ArrayList<>();
        rooms.add(new Room(null, 101, "Standard", 2500, "true"));
        rooms.add(new Room(null, 102, "Deluxe", 3000, "false"));
        rooms.add(new Room(null, 103, "Standard", 2500, "true"));
        rooms.add(new Room(null, 104, "Deluxe", 3000, "true"));
        Mockito.when(roomRepository.findAll()).thenReturn(rooms);

        List<Room> availableRooms = roomService.viewAllAvailable();
        assertEquals(2, availableRooms.size());
    }

    @Test
    public void testViewAllRooms() {
        // Retrieve a list of all rooms
        List<Room> rooms = new ArrayList<>();
        rooms.add(new Room(null, 101, "Standard", 2500, "true"));
        rooms.add(new Room(null, 102, "Deluxe", 3000, "false"));
        rooms.add(new Room(null, 103, "Standard", 2500, "true"));
        rooms.add(new Room(null, 104, "Deluxe", 3000, "true"));
        Mockito.when(roomRepository.findAll()).thenReturn(rooms);

        List<Room> allRooms = roomService.viewAllRooms();
        assertEquals(4, allRooms.size());
    }
}
