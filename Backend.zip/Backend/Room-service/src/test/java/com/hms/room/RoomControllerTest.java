package com.hms.room;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.hms.room.controller.RoomController;
import com.hms.room.entity.Room;
import com.hms.room.exceptions.RoomNotFoundException;
import com.hms.room.service.RoomServiceImpl;

public class RoomControllerTest {

    @InjectMocks
    private RoomController roomController;

    @Mock
    private RoomServiceImpl roomService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testAddRoom_Success() {
        // Create a room and add it successfully
        Room room = new Room(null, 101, "Standard", 2500, "true");
        Mockito.when(roomService.addRoom(room)).thenReturn("Room added successfully");

        ResponseEntity<String> response = roomController.addRoom(room);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Room added successfully", response.getBody());
    }

    @Test
    public void testUpdateRoom_Success() throws RoomNotFoundException {
        // Update an existing room successfully
        int roomNo = 101;
        Room roomToUpdate = new Room(null, roomNo, "Deluxe", 3000, "false");
        Mockito.when(roomService.updateRoom(roomNo, roomToUpdate)).thenReturn(roomToUpdate);

        ResponseEntity<Room> response = roomController.updateRoom(roomNo, roomToUpdate);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(roomToUpdate, response.getBody());
    }

    @Test
    public void testDeleteRoom_Success() throws RoomNotFoundException {
        // Delete an existing room successfully
        int roomNo = 101;
        Mockito.when(roomService.deleteRoom(roomNo)).thenReturn("Room Deleted successfully!!");

        ResponseEntity<String> response = roomController.deleteRoom(roomNo);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Room Deleted successfully!!", response.getBody());
    }

    @Test
    public void testViewRoom_Success() throws RoomNotFoundException {
        // View an existing room successfully
        int roomNo = 101;
        Room roomToView = new Room(null, roomNo, "Standard", 2500, "true");
        Mockito.when(roomService.viewRoom(roomNo)).thenReturn(roomToView);

        ResponseEntity<Room> response = roomController.viewRoom(roomNo);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(roomToView, response.getBody());
    }

    @Test
    public void testViewAllAvailable() {
        // Retrieve a list of available rooms
        List<Room> availableRooms = new ArrayList<>();
        availableRooms.add(new Room(null, 101, "Standard", 2500, "true"));
        availableRooms.add(new Room(null, 102, "Deluxe", 3000, "true"));
        Mockito.when(roomService.viewAllAvailable()).thenReturn(availableRooms);

        ResponseEntity<List<Room> > response = roomController.viewAllAvailable();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    @Test
    public void testViewAllRooms() {
        // Retrieve a list of all rooms
        List<Room> allRooms = new ArrayList<>();
        allRooms.add(new Room(null, 101, "Standard", 2500, "true"));
        allRooms.add(new Room(null, 102, "Deluxe", 3000, "true"));
        Mockito.when(roomService.viewAllRooms()).thenReturn(allRooms);

        ResponseEntity<List<Room> > response = roomController.viewAllRooms();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    // Additional test cases for exception scenarios can be added as needed.
}

