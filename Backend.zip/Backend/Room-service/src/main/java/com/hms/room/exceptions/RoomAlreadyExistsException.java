package com.hms.room.exceptions;

public class RoomAlreadyExistsException extends RuntimeException {

	public RoomAlreadyExistsException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}
	

}
