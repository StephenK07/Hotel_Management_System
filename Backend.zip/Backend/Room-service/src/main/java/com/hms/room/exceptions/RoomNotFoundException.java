package com.hms.room.exceptions;

public class RoomNotFoundException extends Exception {
	public RoomNotFoundException(String msg) {
		super(msg);
	}

}
