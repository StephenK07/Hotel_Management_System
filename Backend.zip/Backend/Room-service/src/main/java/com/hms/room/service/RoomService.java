package com.hms.room.service;

import java.util.List;

import com.hms.room.entity.Room;
import com.hms.room.exceptions.RoomNotFoundException;

public interface RoomService {
	
	public String addRoom(Room room);
	public Room updateRoom(int roomNo,Room room) throws RoomNotFoundException;
	public String deleteRoom(int roomNo) throws RoomNotFoundException;
	public Room viewRoom(int roomNo) throws RoomNotFoundException;
	public List<Room> viewAllAvailable();
	public List<Room> viewAllRooms();
	

}
