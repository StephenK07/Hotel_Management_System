package com.hms.room.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.room.entity.Room;
import com.hms.room.exceptions.RoomAlreadyExistsException;
import com.hms.room.exceptions.RoomNotFoundException;
import com.hms.room.repository.RoomRepository;

@Service
public class RoomServiceImpl implements RoomService {
	
	@Autowired
	private RoomRepository repo;

	@Override
	public String addRoom(Room room) {
		Room rom= repo.findByRoomNo(room.getRoomNo());
		if(rom==null) {
			repo.save(room);
			
			return "Room added successfully";
		}else {
			throw new RoomAlreadyExistsException("Room already exists with given roomNo:"+room.getRoomNo());
		}
		
	}

	@Override
	public Room updateRoom(int roomNo, Room room) throws RoomNotFoundException {
		Room rom = repo.findByRoomNo(roomNo);
		if(rom != null) {
			rom.setRoomNo(room.getRoomNo());
			rom.setRoomType(room.getRoomType());
			rom.setRoomRent(room.getRoomRent());
			rom.setRoomsAvailable(room.getRoomsAvailable());
			return repo.save(rom);
			
			
		}else {
			throw new RoomNotFoundException("Room is not present with the given room number");
		}
	
		
	}

	@Override
	public String deleteRoom(int roomNo) throws RoomNotFoundException {
		Room RoomNo = repo.findByRoomNo(roomNo);
		if(RoomNo!=null) {
			repo.delete(RoomNo);
			
			return "Room Deleted successfully!!";
			
		}else {
			throw new RoomNotFoundException("Room is not present with the given room number");
		}
			
	}

	@Override
	public Room viewRoom(int roomNo) throws RoomNotFoundException {
		Room findByRoomNo = repo.findByRoomNo(roomNo);
		if(findByRoomNo != null) {
			return findByRoomNo;
		}
	else {
		throw new RoomNotFoundException("Room is not present with the given room number");
	}
		
	}

	@Override
	public List<Room> viewAllAvailable() {
		List<Room> findAll = repo.findAll();
		List<Room> availableRooms = new ArrayList<>();
		for(Room room : findAll) {
			if(room.getRoomsAvailable().equals("true")) {
				availableRooms.add(room);
			}
		}
		return availableRooms;
	}

	@Override
	public List<Room> viewAllRooms() {
		
		List<Room> findAll = repo.findAll();
		return findAll;
	}

}


