package com.hms.room.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hms.room.entity.Room;
import com.hms.room.exceptions.RoomNotFoundException;
import com.hms.room.service.RoomServiceImpl;

@RestController
@RequestMapping("/room")
@CrossOrigin("http://localhost:3000")

public class RoomController {
	
	@Autowired
	private RoomServiceImpl impl;
	
	private static Logger logger = LogManager.getLogger();
	
	@PostMapping("/addroom")
	public ResponseEntity<String> addRoom(@RequestBody Room room) {
		logger.info("sending request to add room");
		String save = impl.addRoom(room);
		logger.info("room added");
		return new ResponseEntity<String>(save, HttpStatus.OK);
	}

	@PutMapping("/updateroom/{roomNo}")
	public ResponseEntity<Room> updateRoom(@PathVariable int roomNo,@RequestBody Room room) throws RoomNotFoundException {
		logger.info("sending request to update room");
		Room save = impl.updateRoom(roomNo, room);
		logger.info("room updated");
		return new ResponseEntity<Room>(save, HttpStatus.OK);
		
	}

	@DeleteMapping("/deleteroom/{roomNo}")
	public ResponseEntity<String> deleteRoom(@PathVariable int roomNo) throws RoomNotFoundException {
		logger.info("sending request to delete room");
		String save = impl.deleteRoom(roomNo);
		logger.info("room deleted");
		return new ResponseEntity<String>(save, HttpStatus.OK);
		
	}

	@GetMapping("/viewroom/{roomNo}")
	public ResponseEntity<Room> viewRoom(@PathVariable int roomNo) throws RoomNotFoundException {
		logger.info("sending request to view room");
	    Room save = impl.viewRoom(roomNo);
		logger.info("viewing the room");
		return new ResponseEntity<Room>(save, HttpStatus.OK);
	}

	@GetMapping("/viewAllRooms")
	public ResponseEntity<List<Room>> viewAllAvailable() {
		logger.info("sending request to view all available rooms");
		List<Room> save = impl.viewAllAvailable();
		logger.info("viewing all rooms");
		return new ResponseEntity<List<Room>>(save, HttpStatus.OK);
	}
	@GetMapping("/AllRooms")
	public ResponseEntity<List<Room>> viewAllRooms() {
		logger.info("sending request to view all rooms");
		List<Room> save = impl.viewAllRooms() ;
		logger.info("viewing all rooms");
		return new ResponseEntity<List<Room>>(save, HttpStatus.OK);
	}


}
