package com.hms.user.feignClient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.hms.user.entity.Room;

@FeignClient(name="Room-service",url="http://localhost:8081/room")
public interface RoomClient {

	@PostMapping("/addroom")
	public String addRoom(@RequestBody Room room);
	
	@GetMapping("/viewAllRooms")
	public List<Room> viewAllAvailable();
	
	@PutMapping("/updateroom/{roomNo}")
	public Room updateRoom(@PathVariable int roomNo,@RequestBody Room room);
}
