package com.hms.user.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hms.user.entity.Login;
import com.hms.user.exception.ReceptionistNotFoundException;
import com.hms.user.repository.LoginRepository;



@Service
public class ReceptionServiceImpl implements ReceptionService{

	@Autowired
	private LoginRepository repo;
	
	 

	

	@Override
	public String updateReceptionist(String username, Login receptionist) {
		
		Optional<Login> custopt = repo.findByUsername(username);
		if (custopt.isPresent()) {
			Login c1 = custopt.get();

			c1.setEmail(receptionist.getEmail());
			c1.setFirstName(receptionist.getFirstName());
			c1.setLastName(receptionist.getLastName());
			c1.setMobileNumber(receptionist.getMobileNumber());
			c1.setPassword(receptionist.getPassword());
			c1.setUsername(receptionist.getUsername());
			repo.save(c1);
			return "receptionist updated sucessfully";
		} else {
			throw new ReceptionistNotFoundException("Receptionist not found");
		}
		
	}

	@Override
	public String deleteReceptionist(String username) {
		Optional<Login> custopt = repo.findByUsername(username);
		if (custopt.isPresent()) {
			Login c = custopt.get();
			
			repo.delete(c);
			return "manager deleted successfully";
		} else {
			throw new ReceptionistNotFoundException("Receptionist not found with username");
		}
		
	}
	

}
