package com.hms.user.exception;

public class ManagerNotFoundException extends RuntimeException  {
	
	public ManagerNotFoundException(String msg) {
		super(msg);
	}

}
