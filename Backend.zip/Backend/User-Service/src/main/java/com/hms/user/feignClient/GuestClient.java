package com.hms.user.feignClient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.hms.user.entity.Guest;

@FeignClient(name = "guest-service", url = "http://localhost:8080/guest")

public interface GuestClient {

	@PostMapping("/addguest")
	public Guest addGuest(@RequestBody Guest guest);

	@PutMapping("/updateguest/{guestId}")

	public Guest updateGuest(@PathVariable String guestId, @RequestBody Guest guest);

	@DeleteMapping("/deleteguest/{guestId}")

	public String deleteGuest(@PathVariable String guestId);

	@GetMapping("/viewguest/{guestId}")

	public Guest viewGuest(@PathVariable String guestId);

	@GetMapping("/viewall")

	public List<Guest> viewAllGuest();

}