package com.hms.user.service;

import com.hms.user.entity.Login;

public interface ManagerService {
	
    public String updateManager(String username,Login manager);
	
	public String deleteManager(String username);
	
	

}
