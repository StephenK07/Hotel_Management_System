package com.hms.user.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.hms.user.jwt.TokenFilter;
import com.hms.user.service.UserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
	
	@Autowired
	UserDetailsServiceImpl userDetailsServiceImpl;
	
	@Autowired
	TokenFilter tokenFilter;

	@Bean
	public SecurityFilterChain doFilter(HttpSecurity http) throws Exception {
		
		return http.csrf().disable()
				//.exceptionHandling()
				//.authenticationEntryPoint(entryPointJwt)
				//.and()
				.authorizeHttpRequests().requestMatchers("/auth/generateToken","/auth/**").permitAll()
				.and()
				.authorizeHttpRequests().requestMatchers("/auth/user/**").authenticated()
				.and()
				.authorizeHttpRequests().requestMatchers("/manager/**").authenticated()
				.and()
				.authorizeHttpRequests().requestMatchers("/reception/**").authenticated()
				
				.and()
				.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
				.addFilterBefore(tokenFilter, UsernamePasswordAuthenticationFilter.class)
				.build();

	}

	@Bean
	DaoAuthenticationProvider daoAuthenticationProvider() {
		DaoAuthenticationProvider daoProvider = new DaoAuthenticationProvider();
		daoProvider.setUserDetailsService(userDetailsServiceImpl);
		daoProvider.setPasswordEncoder(passwordEncoder());
		return daoProvider;
	}
	
	@Bean
    public PasswordEncoder passwordEncoder() { 
        return new BCryptPasswordEncoder(); 
    } 

}
