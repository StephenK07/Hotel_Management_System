package com.hms.user.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hms.user.entity.Login;
import com.hms.user.exception.UserAlreadyExistsException;
import com.hms.user.repository.LoginRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	LoginRepository loginRepository;

	@Autowired
	private PasswordEncoder encoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		Optional<Login> opt = loginRepository.findByUsername(username);

		if (opt.isPresent()) {
			Login login = opt.get();
			return UserDetailsImpl.getUser(login);
		} else {
			throw new UsernameNotFoundException("User Not Found with username:" + username);
		}
	}

	public String addUser(Login login) {
		Optional<Login> opt = loginRepository.findByUsername(login.getUsername());
		if(opt.isPresent()) {
			throw new UserAlreadyExistsException("user already exists");
		}else {
			login.setPassword(encoder.encode(login.getPassword()));
			loginRepository.save(login);
			return "User Added Successfully";
			
		}
		
	}

}
