package com.hms.user.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hms.user.entity.Login;
import com.hms.user.entity.Room;
import com.hms.user.feignClient.RoomClient;
import com.hms.user.service.ManagerServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/manager")
@CrossOrigin("*")
public class ManagerController {
	
	@Autowired
	private ManagerServiceImpl impl;
	
	@Autowired
	private RoomClient client;
	
	
	
	private static Logger logger = LogManager.getLogger();
	
	

	
	@PostMapping("/addroom")
	@PreAuthorize("hasAuthority('ROLE_MANAGER')")
	public ResponseEntity<String> addRoom(@RequestBody Room room){
		logger.info("sending request to add room");
		String add = client.addRoom(room);
		logger.info("room added successfully");
		return new ResponseEntity<String>(add, HttpStatus.OK);
		
	}
	
	@GetMapping("/viewall")
	@PreAuthorize("hasAnyAuthority('ROLE_RECEPTIONIST','ROLE_MANAGER')")
	public ResponseEntity<List<Room>> viewAllAvailable(){
		logger.info("sending request to viewall room");
		List<Room> all = client.viewAllAvailable();
		logger.info("viewing rooms from database");
		return new ResponseEntity<List<Room>>(all, HttpStatus.OK);
		
		
	}
	
	@PutMapping("/updateroom/{roomNo}")
	@PreAuthorize("hasAuthority('ROLE_MANAGER')")
	public ResponseEntity<Room> updateRoom(@PathVariable int roomNo,@RequestBody Room room){
		logger.info("sending request to update room");
	    Room update = client.updateRoom(roomNo, room);
	   	logger.info("updated successfully");
	   	return new ResponseEntity<Room>(update, HttpStatus.OK);
		
	}
	
	
	
	

	

}