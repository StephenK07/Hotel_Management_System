package com.hms.user.service;

public interface OwnerService {

}
