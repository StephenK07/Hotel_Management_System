package com.hms.user.service;

import com.hms.user.entity.Login;

public interface ReceptionService {
	
    public String updateReceptionist(String username,Login receptionist );
	
	public String deleteReceptionist(String username);
	
	
	
	

}
