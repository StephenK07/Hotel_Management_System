package com.hms.user.controller;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hms.user.entity.Login;
import com.hms.user.jwt.JwtUtility;
import com.hms.user.request.LoginRequest;
import com.hms.user.response.JSONResponse;
import com.hms.user.service.UserDetailsImpl;
import com.hms.user.service.UserDetailsServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth")
@CrossOrigin("*")
public class AuthController {

	@Autowired
	DaoAuthenticationProvider daoAuthenticationProvider;

	@Autowired
	JwtUtility jwtUtility;

	@Autowired
	UserDetailsServiceImpl service;

	@PostMapping("/addNewUser")
	public String addNewUser(@Valid @RequestBody Login userInfo) {
		return service.addUser(userInfo);
	}

	

	@PostMapping("/signin")
	public ResponseEntity<?> validateUser(@RequestBody LoginRequest loginRequest) {

		Authentication authenticate = daoAuthenticationProvider.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

		JSONResponse jsonResponse = null;

		if (authenticate.isAuthenticated()) {

			String token = jwtUtility.generateToken(authenticate);
			UserDetailsImpl userDetailsImpl = (UserDetailsImpl) authenticate.getPrincipal();
			Collection<? extends GrantedAuthority> authorities = userDetailsImpl.getAuthorities();
			List<String> collect = authorities.stream().map(GrantedAuthority::getAuthority)
					.collect(Collectors.toList());
			jsonResponse = new JSONResponse(token, userDetailsImpl.getUsername(), collect);
		}

		return ResponseEntity.ok(jsonResponse);

	}

}
