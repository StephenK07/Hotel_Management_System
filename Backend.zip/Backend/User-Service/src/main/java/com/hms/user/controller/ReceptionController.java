package com.hms.user.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hms.user.entity.Guest;
import com.hms.user.entity.Login;
import com.hms.user.entity.Reservation;
import com.hms.user.feignClient.GuestClient;
import com.hms.user.feignClient.ReservationClient;
import com.hms.user.service.ReceptionServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/reception")
@CrossOrigin("*")
public class ReceptionController {

	@Autowired
	private ReceptionServiceImpl impl;
	
	@Autowired
	private GuestClient client;
	@Autowired
	private ReservationClient reser;

	private static Logger logger = LogManager.getLogger();

	@PutMapping("/updatreceptionist/{username}")
	public ResponseEntity<String> updateReceptionist(@Valid @PathVariable String username,
			@Valid @RequestBody Login receptionist) {
		logger.info("sending request to update receptionist");
		String update = impl.updateReceptionist(username, receptionist);
		logger.info("receptionist updated");
		return new ResponseEntity<String>(update, HttpStatus.OK);
	}

	@DeleteMapping("/deletereceptionist/{username}")
	public ResponseEntity<String> deleteReceptionist(@Valid @PathVariable String username) {
		logger.info("sending request to delete receptionist");
		String delete = impl.deleteReceptionist(username);

		logger.info("receptionist deleted");
		return new ResponseEntity<String>(delete, HttpStatus.OK);
	}

	@PostMapping("/addguest")

	@PreAuthorize("hasAuthority('ROLE_RECEPTIONIST')")

	public ResponseEntity<Guest> addGuest(@RequestBody Guest guest) {

		logger.info("sending request to add guest");

		Guest add = client.addGuest(guest);

		logger.info("guest added successfully");

		return new ResponseEntity<Guest>(add, HttpStatus.OK);

	}

	@PutMapping("/updateguest/{guestId}")

	@PreAuthorize("hasAuthority('ROLE_RECEPTIONIST')")

	public ResponseEntity<Guest> updateGuest(@PathVariable String guestId, @RequestBody Guest guest) {

		logger.info("sending request to update guest");

		Guest update = client.updateGuest(guestId, guest);

		logger.info("guest updated successfully");

		return new ResponseEntity<Guest>(update, HttpStatus.OK);

	}

	@DeleteMapping("/deleteguest/{guestId}")

	@PreAuthorize("hasAuthority('ROLE_RECEPTIONIST')")

	public ResponseEntity<String> deleteGuest(@PathVariable String guestId) {

		logger.info("sending request to delete guest");

		String delete = client.deleteGuest(guestId);

		logger.info("guest deleted successfully");

		return new ResponseEntity<String>(delete, HttpStatus.OK);

	}

	@GetMapping("/viewguest/{guestId}")

	@PreAuthorize("hasAuthority('ROLE_RECEPTIONIST')")

	public ResponseEntity<Guest> viewGuest(@PathVariable String guestId) {

		logger.info("sending request to view guest from database");

		Guest view = client.viewGuest(guestId);

		logger.info("viewing guest from the database");

		return new ResponseEntity<Guest>(view, HttpStatus.OK);

	}

	@GetMapping("/viewall")

	@PreAuthorize("hasAuthority('ROLE_RECEPTIONIST')")

	public ResponseEntity<List<Guest>> viewAllGuest() {

		logger.info("sending request to view guest from database");

		List<Guest> all = client.viewAllGuest();

		logger.info("viewing guests from the database");

		return new ResponseEntity<List<Guest>>(all, HttpStatus.OK);

	}

	@PostMapping("/addreservation")

	@PreAuthorize("hasAuthority('ROLE_RECEPTIONIST')")

	public ResponseEntity<String> addReservation(@RequestBody Reservation reservation) {

		logger.info("sending request to add reservation");

		String add = reser.addReservation(reservation);

		logger.info("reservation added successfully");

		return new ResponseEntity<String>(add, HttpStatus.OK);

	}

	@PutMapping("/updatereservation/{reservationId}")

	@PreAuthorize("hasAuthority('ROLE_RECEPTIONIST')")

	public ResponseEntity<String> updateReservation(@PathVariable String reservationId,
			@RequestBody Reservation reservation) {

		logger.info("sending request to update reservation");

		String update = reser.updateReservation(reservationId, reservation);

		logger.info("reservation updated successfully");

		return new ResponseEntity<String>(update, HttpStatus.OK);

	}

	@DeleteMapping("/deletereservation/{reservationId}")

	@PreAuthorize("hasAuthority('ROLE_RECEPTIONIST')")

	public ResponseEntity<String> deleteReservation(@PathVariable String reservationId) {

		logger.info("sending request to delete reservation");

		String delete = reser.deleteReservation(reservationId);

		logger.info("reservation deleted successfully");

		return new ResponseEntity<String>(delete, HttpStatus.OK);

	}

	@GetMapping("/viewreservation/{reservationId}")

	@PreAuthorize("hasAuthority('ROLE_RECEPTIONIST')")

	public ResponseEntity<Reservation> viewReservation(@PathVariable String reservationId) {

		logger.info("sending request to view reservation from database");

		Reservation view = reser.viewReservation(reservationId);

		logger.info("viewing reservation from the database");

		return new ResponseEntity<Reservation>(view, HttpStatus.OK);

	}

	@GetMapping("/viewAllReservations")

	@PreAuthorize("hasAuthority('ROLE_RECEPTION')")

	public ResponseEntity<List<Reservation>> viewAllReservation() {

		logger.info("sending request to view reservation from database");

		List<Reservation> all = reser.viewAllReservation();

		logger.info("viewing reservations from the database");

		return new ResponseEntity<List<Reservation>>(all, HttpStatus.OK);

	}

}
