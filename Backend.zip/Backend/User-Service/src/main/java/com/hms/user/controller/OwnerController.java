package com.hms.user.controller;

import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin("*")
public class OwnerController {

}
