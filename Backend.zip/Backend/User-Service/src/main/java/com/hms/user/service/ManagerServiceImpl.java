package com.hms.user.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hms.user.entity.Login;
import com.hms.user.exception.ManagerNotFoundException;
import com.hms.user.repository.LoginRepository;
@Service
public class ManagerServiceImpl implements ManagerService {
	
	@Autowired
	LoginRepository repo;
	

	@Override
	public String updateManager(String username, Login manager) {
		Optional<Login> custopt = repo.findByUsername(username);
		if (custopt.isPresent()) {
			Login c1 = custopt.get();

			c1.setEmail(manager.getEmail());
			c1.setFirstName(manager.getFirstName());
			c1.setLastName(manager.getLastName());
			c1.setMobileNumber(manager.getMobileNumber());
			c1.setPassword(manager.getPassword());
			c1.setUsername(manager.getUsername());
			repo.save(c1);
			return "manager updated sucessfully";
		} else {
			throw new ManagerNotFoundException("Manager not found");
		}
	}

	@Override
	public String deleteManager(String username) {
		Optional<Login> custopt = repo.findByUsername(username);
		if (custopt.isPresent()) {
			Login c = custopt.get();
			
			repo.delete(c);
			return "manager deleted successfully";
		} else {
			throw new ManagerNotFoundException("Manager not found with username");
		}
	}

	
	
	

}
