package com.hms.user.service;

public class OwnerServiceImpl {

}
