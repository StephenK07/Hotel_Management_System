package com.hms.user.jwt;

import java.security.Key;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.hms.user.service.UserDetailsImpl;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtility {

	@Value("${jwtSecret}")
	private String jwtSecret;

	@Value("${jwtExpirationMs}")
	private int jwtExpirationMs;

	public String generateToken(Authentication authentication) {

		UserDetailsImpl userDetailsImpl = (UserDetailsImpl) authentication.getPrincipal();

		String username = userDetailsImpl.getUsername();
		Date issuedAt = new Date(System.currentTimeMillis());
		Date exp = new Date(System.currentTimeMillis() + jwtExpirationMs);

		return Jwts.builder()
				.setSubject(username)
				.setIssuedAt(issuedAt)
				.setExpiration(exp)
				.signWith(getSignKey(), SignatureAlgorithm.HS256).compact();
	}

	private Key getSignKey() {
		 byte[] keyBytes= Decoders.BASE64.decode(jwtSecret); 
		return Keys.hmacShaKeyFor(keyBytes);
	}
	
	public String extractUsername(String token) {
		return parseClaims(token).getSubject();
	}

	public Claims parseClaims(String token) {
		return Jwts.parser()
				.setSigningKey(getSignKey())
				.parseClaimsJws(token).getBody();
	}

	public boolean validateToken(String token) {

		try {
			Jwts
			.parser()
			.setSigningKey(getSignKey())
			.parseClaimsJws(token);
			return true;
		} catch (Exception ex) {

		}
		return false;

	}
	
}
