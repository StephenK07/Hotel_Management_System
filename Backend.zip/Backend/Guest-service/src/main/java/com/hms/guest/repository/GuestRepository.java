package com.hms.guest.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.hms.guest.entity.Guest;
@Repository
public interface GuestRepository extends MongoRepository<Guest, String> {
	
	Optional<Guest> findByGuestId(String guestId);
	Optional<Guest> findByEmail(String email);

}
