package com.hms.guest.controller;

import java.util.List;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hms.guest.entity.Guest;
import com.hms.guest.service.GuestServiceImpl;


@RestController
@RequestMapping("/guest")
@CrossOrigin("http://localhost:3000")
public class GuestController {
	
	@Autowired
	private GuestServiceImpl impl;
	
	private static Logger logger = LogManager.getLogger();
	

	
	@PostMapping("/addguest")
	public ResponseEntity<Guest> addGuest(@RequestBody Guest guest) {
		logger.info("sending request to add guest");
		Guest save = impl.addGuest(guest);
		logger.info("guest added");
		return new ResponseEntity<Guest>(save, HttpStatus.OK);

	}

	@PutMapping("/updateguest/{guestId}")
	public ResponseEntity<Guest> updateGuest(@PathVariable String guestId, @RequestBody Guest guest){
		logger.info("sending request to update guest");
		Guest update = impl.updateGuest(guestId, guest);
		logger.info("guest updated");
		return new ResponseEntity<Guest>(update, HttpStatus.OK);
		
	}

	@DeleteMapping("/deleteguest/{guestId}")
	public ResponseEntity<String> deleteGuest(@PathVariable String guestId){
		logger.info("sending request to delete guest");
		String deleteGuest = impl.deleteGuest(guestId);
		logger.info("guest deleted");
		return new ResponseEntity<String>(deleteGuest, HttpStatus.OK);		
		
	}

	@GetMapping("/viewguest/{guestId}")
	public ResponseEntity<Guest> viewGuest(@PathVariable String guestId) {
		logger.info("sending request to view guest through id");
		Guest view = impl.viewGuest(guestId);
		logger.info("viewing guest from the database");
		return new ResponseEntity<Guest>(view, HttpStatus.OK);	
	}

	@GetMapping("/viewall")
	public ResponseEntity<List<Guest>> viewAllGuest() {
		logger.info("sending request to view guest through id");
		List<Guest> all = impl.viewAllGuest();
		logger.info("viewing all guests from the database");
		return new ResponseEntity<List<Guest>>(all, HttpStatus.OK);
		
		
	}

}
