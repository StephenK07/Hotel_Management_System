package com.hms.guest.service;

import java.util.List;

import com.hms.guest.entity.Guest;
import com.hms.guest.exceptions.NoIdExistsException;

public interface GuestService {

	public Guest addGuest(Guest guest);
	public Guest updateGuest(String guestId,Guest guest) throws NoIdExistsException;
	public String deleteGuest(String guestId) throws NoIdExistsException;
	public Guest viewGuest(String guestId);
	public List<Guest> viewAllGuest();
}
