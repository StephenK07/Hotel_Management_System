package com.hms.guest.exceptions;

public class NoIdExistsException extends RuntimeException {
	public NoIdExistsException(String msg) {
		super(msg);
	}
}
