package com.hms.guest.exceptions;

public class EmailAlreadyExists extends RuntimeException {
	public EmailAlreadyExists(String msg) {
		super(msg);
	}

}
