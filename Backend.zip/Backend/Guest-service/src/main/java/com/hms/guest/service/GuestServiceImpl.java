package com.hms.guest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.guest.entity.Guest;
import com.hms.guest.exceptions.EmailAlreadyExists;
import com.hms.guest.exceptions.NoIdExistsException;
import com.hms.guest.repository.GuestRepository;
@Service
public class GuestServiceImpl implements GuestService {

	@Autowired
	private GuestRepository repo;

	@Override
	public Guest addGuest(Guest guest) {
		Optional<Guest> opt = repo.findByEmail(guest.getEmail());
		if(opt.isPresent()) {
			throw new EmailAlreadyExists("Email already exists!,please change the Email");
			
		}else {
			return repo.save(guest);
			
		}

		
	}

	@Override
	public Guest updateGuest(String guestId, Guest guest)  {
		Optional<Guest> opt = repo.findById(guestId);
		if (opt.isPresent()) {
			Guest guest2 = opt.get();
			guest2.setName(guest.getName());
			guest2.setMobileNumber(guest.getMobileNumber());
			guest2.setEmail(guest.getEmail());
			guest2.setGender(guest.getGender());
			guest2.setAddress(guest.getAddress());
			return repo.save(guest2);
		} else {
			throw new NoIdExistsException("id is not present");
		}
	
	}

	@Override
	public String deleteGuest(String guestId) throws NoIdExistsException {
		Optional<Guest> opt = repo.findById(guestId);
		if(opt.isPresent()) {
			Guest guest = opt.get();
			repo.delete(guest);
			return "The Guest deleted successfully";
		}else {
			throw new NoIdExistsException("The given id is not present");
		}
		
	}

	@Override
	public Guest viewGuest(String guestId) {
		Optional<Guest> opt = repo.findById(guestId);
		if(opt.isPresent()) {
			Guest guest = opt.get();
			return guest;
		}
		else {
			throw new NoIdExistsException("Guest id not found!");
		}
	}

	@Override
	public List<Guest> viewAllGuest() {
		return repo.findAll();
	}

}
