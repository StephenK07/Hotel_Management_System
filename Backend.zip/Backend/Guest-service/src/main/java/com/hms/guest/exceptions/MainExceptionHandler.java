package com.hms.guest.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.hms.guest.entity.ErrorResponse;

@ControllerAdvice
public class MainExceptionHandler {
	
	@ExceptionHandler(NoIdExistsException.class)
	public ResponseEntity<ErrorResponse> handleException(NoIdExistsException ex) {
		ErrorResponse err = new ErrorResponse(ex.getMessage());

		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);

	}
	
	@ExceptionHandler(EmailAlreadyExists.class)
	public ResponseEntity<ErrorResponse> handleException(EmailAlreadyExists ex) {
		ErrorResponse err = new ErrorResponse(ex.getMessage());

		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);

	}

}
