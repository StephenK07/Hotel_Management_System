package com.hms;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.hms.guest.entity.ErrorResponse;
import com.hms.guest.exceptions.EmailAlreadyExists;
import com.hms.guest.exceptions.MainExceptionHandler;
import com.hms.guest.exceptions.NoIdExistsException;

public class MainExceptionHandlerTest {

    private MainExceptionHandler mainExceptionHandler = new MainExceptionHandler();

    @Test
    void testHandleNoIdExistsException() {
        NoIdExistsException ex = new NoIdExistsException("No such ID exists.");
        ResponseEntity<ErrorResponse> response = mainExceptionHandler.handleException(ex);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("No such ID exists.", response.getBody().getMessage());
    }

    @Test
    void testHandleEmailAlreadyExistsException() {
        EmailAlreadyExists ex = new EmailAlreadyExists("Email already exists.");
        ResponseEntity<ErrorResponse> response = mainExceptionHandler.handleException(ex);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Email already exists.", response.getBody().getMessage());
    }
}
