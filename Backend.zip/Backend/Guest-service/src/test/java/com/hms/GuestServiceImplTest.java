package com.hms;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.hms.guest.entity.Guest;
import com.hms.guest.exceptions.EmailAlreadyExists;
import com.hms.guest.exceptions.NoIdExistsException;
import com.hms.guest.repository.GuestRepository;
import com.hms.guest.service.GuestServiceImpl;

public class GuestServiceImplTest {

    @InjectMocks
    private GuestServiceImpl guestService;

    @Mock
    private GuestRepository guestRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddGuest_Success() {
        Guest newGuest = new Guest("John Doe", "john@example.com", "1234567890", "Male", "123 Main St", null);
        
        Mockito.when(guestRepository.findByEmail("john@example.com")).thenReturn(Optional.empty());
        Mockito.when(guestRepository.save(newGuest)).thenReturn(newGuest);
        
        Guest result = guestService.addGuest(newGuest);
        
        assertEquals(newGuest, result);
    }

    @Test
    void testAddGuest_EmailAlreadyExists() {
        Guest existingGuest = new Guest("Existing Guest", "existing@example.com", "9876543210", "Female", "456 Elm St", null);
        
        Mockito.when(guestRepository.findByEmail("existing@example.com")).thenReturn(Optional.of(existingGuest));
        
        assertThrows(EmailAlreadyExists.class, () -> {
            guestService.addGuest(existingGuest);
        });
    }

    @Test
    void testUpdateGuest_Success() {
        String guestId = "1";
        Guest existingGuest = new Guest("Existing Guest", "existing@example.com", "9876543210", "Female", "456 Elm St", guestId);
        Guest updatedGuest = new Guest("Updated Guest", "updated@example.com", "1234567890", "Male", "789 Oak St", guestId);
        
        Mockito.when(guestRepository.findById(guestId)).thenReturn(Optional.of(existingGuest));
        Mockito.when(guestRepository.save(existingGuest)).thenReturn(existingGuest);
        
        Guest result = guestService.updateGuest(guestId, updatedGuest);
        
        assertEquals(updatedGuest, result);
    }

    @Test
    void testUpdateGuest_NoIdExists() {
        String guestId = "1";
        Guest updatedGuest = new Guest("Updated Guest", "updated@example.com", "1234567890", "Male", "789 Oak St", guestId);
        
        Mockito.when(guestRepository.findById(guestId)).thenReturn(Optional.empty());
        
        assertThrows(NoIdExistsException.class, () -> {
            guestService.updateGuest(guestId, updatedGuest);
        });
    }

    @Test
    void testDeleteGuest_Success() {
        String guestId = "1";
        Guest existingGuest = new Guest("Existing Guest", "existing@example.com", "9876543210", "Female", "456 Elm St", guestId);
        
        Mockito.when(guestRepository.findById(guestId)).thenReturn(Optional.of(existingGuest));
        
        String result = guestService.deleteGuest(guestId);
        
        assertEquals("The Guest deleted successfully", result);
    }

    @Test
    void testDeleteGuest_NoIdExists() {
        String guestId = "1";
        
        Mockito.when(guestRepository.findById(guestId)).thenReturn(Optional.empty());
        
        assertThrows(NoIdExistsException.class, () -> {
            guestService.deleteGuest(guestId);
        });
    }

    @Test
    void testViewGuest_Success() {
        String guestId = "1";
        Guest existingGuest = new Guest("Existing Guest", "existing@example.com", "9876543210", "Female", "456 Elm St", guestId);
        
        Mockito.when(guestRepository.findById(guestId)).thenReturn(Optional.of(existingGuest));
        
        Guest result = guestService.viewGuest(guestId);
        
        assertEquals(existingGuest, result);
    }

    @Test
    void testViewGuest_NoIdExists() {
        String guestId = "1";
        
        Mockito.when(guestRepository.findById(guestId)).thenReturn(Optional.empty());
        
        assertThrows(NoIdExistsException.class, () -> {
            guestService.viewGuest(guestId);
        });
    }

    @Test
    void testViewAllGuest() {
        List<Guest> guests = new ArrayList<>();
        guests.add(new Guest("Guest 1", "guest1@example.com", "1234567890", "Male", "123 Street", null));
        guests.add(new Guest("Guest 2", "guest2@example.com", "9876543210", "Female", "456 Avenue", null));
        
        Mockito.when(guestRepository.findAll()).thenReturn(guests);
        
        List<Guest> result = guestService.viewAllGuest();
        
        assertEquals(guests, result);
    }
}
