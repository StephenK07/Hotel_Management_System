package com.hms;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.hms.guest.controller.GuestController;
import com.hms.guest.entity.Guest;
import com.hms.guest.exceptions.EmailAlreadyExists;
import com.hms.guest.service.GuestServiceImpl;

public class GuestControllerTest {

    private GuestController guestController;
    private GuestServiceImpl guestService;

    @BeforeEach
    void setUp() {
        guestService = mock(GuestServiceImpl.class);
        guestController = new GuestController();
    }

    @Test
    void testAddGuest_Success() {
        Guest newGuest = new Guest("John Doe", "john@example.com", "1234567890", "Male", "123 Main St", null);
        
        when(guestService.addGuest(newGuest)).thenReturn(newGuest);
        
        ResponseEntity<Guest> response = guestController.addGuest(newGuest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(newGuest, response.getBody());
    }

    @Test
    void testAddGuest_EmailAlreadyExists() {
        Guest existingGuest = new Guest("Existing Guest", "existing@example.com", "9876543210", "Female", "456 Elm St", null);
        
        when(guestService.addGuest(existingGuest)).thenThrow(EmailAlreadyExists.class);
        
        ResponseEntity<Guest> response = guestController.addGuest(existingGuest);
        
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        // You can also assert the response body or any other relevant data.
    }

    // Similarly, you can write test cases for other controller methods (updateGuest, deleteGuest, viewGuest, viewAllGuest).
}
