package com.hms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.beans.factory.annotation.Autowired;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class GuestServiceApplicationTests {

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void testApplicationStarts() {
        // You can add test cases here to verify specific functionality of your application.
        // For example, you can make HTTP requests to your application's endpoints and assert the responses.
        // This test is just to check if the application starts.

        // Example:
        // String result = restTemplate.getForObject("/your-api-endpoint", String.class);
        // Assertions.assertEquals("Expected Result", result);
    }
}
