import React, { useState } from 'react';

import './owner.css'; // Import your CSS file here

function OwnerPage() {
  const [isResponsive, setResponsive] = useState(false);
  const toggleResponsive = () => {
    setResponsive(!isResponsive);
  };
  return (

    <div>

      <div className={`topnav ${isResponsive ? 'responsive' : ''}`}>

        <a href="/" className="active">Home</a>
        <a href="/contact">Contact</a>

        <div className="dropdown">

          <button className="dropbtn">Hotel Details

            <i className="fa fa-caret-down"></i>

          </button>

          <div className="dropdown-content">

            

            <a href="/rooms">Room Details</a>

            <a href="/ManagerReservation">Reservation Details</a>

            <a href="/allpayments">Payment Details</a>

          </div>

        </div>

        <a href="#about">About</a>

        <a href="javascript:void(0);" style={{ fontSize: '15px' }} className="icon" onClick={toggleResponsive}>&#9776;</a>

 

        <div className="centered-text h1">

          <h1>Welcome Owner</h1>

        </div>

      </div>

     

      <div className="image-container">

        <img src="https://images.unsplash.com/photo-1625244724120-1fd1d34d00f6?auto=format&fit=crop&q=80&w=1000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWxzfGVufDB8fDB8fHww" alt="First Image" />

        <img src="https://www.princehotels.com/wp-content/uploads/2019/04/aboutslider2-1.jpg" alt="Second Image" />

        <img src="https://www.swissotel.com/assets/0/92/3686/3768/3770/6442451433/ae87da19-9f23-450a-8927-6f4c700aa104.jpg" alt="Third Image" />

        <img src="https://hycinthhotels.com/wp-content/uploads/elementor/thumbs/3-4-q434jpyujgpidqk6n3vf25g5zkbkggwkkx44xsh1so.jpg" alt="Fourth Image" />

      </div>

    </div>

  );

}

 

export default OwnerPage;