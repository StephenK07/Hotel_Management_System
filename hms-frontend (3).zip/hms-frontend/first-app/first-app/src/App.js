import React from "react";

import Header from "./Header/header";
import Contact from './Home/contact';
import About from "./Home/about";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import LoginPage from "./Home/login";
import ManagerHome from "./Home/manager";
import RoomList from "./Home/viewrooms";
import Addroom from "./Home/addroom";
import UpdateRoom from "./Home/updateroom";
import ReceptionHome from "./Reception/reception";
import AvailableRooms from "./Reception/availableroom";
import AddReservation from "./Reception/addreservation";
import ReservationList from "./Reception/viewreservation";
import UpdateReservation from "./Reception/updatereservation";

import AddGuest from "./Reception/addguest";
import ViewGuests from "./Reception/viewguests";
import UpdateGuest from "./Reception/updateguest";
import OwnerPage from "./Owner/owner";
import Signup from "./Home/signup";
import AllRoomsList from "./Home/allrooms";
import AllReservation from "./Home/managerreservation";
import Payment from "./Reception/payment";
import AllPayments from "./Reception/allpayments";
import BookingPage from "./Reception/booking";

function App() {
  

  return (
    <div>
      
      <BrowserRouter>
      <Routes>
      <Route path="/" element={<Header/>}/>
      <Route path="/contact" element={<Contact />}/>
      <Route path="/about" element={<About/>}/>
      <Route path="/login" element={<LoginPage/>}/>
      <Route path="/SignUp" element={<Signup/>}/>
      <Route path="/ManagerHome" element={<ManagerHome/>}/>

      <Route path="/ManagerReservation" element={<AllReservation/>}/>
      <Route path="/viewrooms" element={<RoomList/>}/>
      <Route path="/allrooms" element={<AllRoomsList/>}/>
      <Route path="/addroom" element={<Addroom/>}/>
      <Route path="/updateRoom/:roomNo" element={<UpdateRoom/>}/>
      <Route path="/reception" element={<ReceptionHome/>}/>

      <Route path="/rooms" element={<AvailableRooms/>}/>
      <Route path="/add" element={<AddReservation/>}/>
      <Route path="/viewreservation" element={<ReservationList/>}/>
      <Route path="/updateReservation/:reservationId" element={<UpdateReservation/>}/>
      <Route path="/addguest" element={<AddGuest/>}/>
      <Route path="/viewguests" element={<ViewGuests/>}/>
      <Route path="/updateguest/:guestId" element={<UpdateGuest/>}/>

      <Route path="/payment" element={<Payment/>}/>
      <Route path="/allpayments" element={<AllPayments/>}/>
      <Route path="/booking" element={<BookingPage/>}/>


      <Route path="/owner" element={<OwnerPage/>}/>
      
      
     

      </Routes>
      </BrowserRouter>
      
     
    </div>

   
  );
}

export default App;