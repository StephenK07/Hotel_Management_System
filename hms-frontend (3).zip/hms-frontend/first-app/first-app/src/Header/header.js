import { Alert } from 'bootstrap';

import React from 'react';

//import Footer from './Footer';

import './header.css';

import Navbar from '../Home/Navbar';
import Footer from '../Footer/Footer';

 

function Home() {

 

    const handleBookNow=(e)=>{

e.preventDefault();

window.location.href="http://localhost:3000/login"

    }

  return (
    <>

    <div>

        <Navbar/>

    <div className="hotel-background">

      <div className="content">

        <h1 className='welcomeheader'>WELCOME</h1>

        {/* <p>Your Home Away from Home</p> */}

        <p>Standard Room starts with Rs 2500/- </p>

        <button className="book-button" onClick={handleBookNow}>Book Now</button>

      </div>

    </div>

    <div className='room-cards'>

    <div className="card">

      <img

        src="https://w0.peakpx.com/wallpaper/205/649/HD-wallpaper-hotel-room-interior-design-luxury-hotel-apartments-modern-interior-design-classic-style-luxury-chandelier.jpg"

        alt="Card Image"

        className="card-image"

      />

      <div className="card-content">

        <h3 className="card-title">Queen Room</h3>

        <p className="card-text">A "Queen Room" is a type of hotel room that typically features a queen-sized bed. It's a popular choice for couples or solo travelers looking for a comfortable and cozy room to stay in.</p>

        <a href="/queenroom" className="card-link">

          Learn More

        </a>

      </div>

    </div>

    <div className="card">

      <img

        src="https://img.freepik.com/premium-photo/3d-rendering-beautiful-luxury-bedroom-suite-hotel-with-tv_105762-1584.jpg?size=626&ext=jpg"

        alt="Card Image"

        className="card-image"

      />

      <div className="card-content">

        <h3 className="card-title">King Room</h3>

        <p className="card-text">A "King Room" in a hotel is a type of guest room that typically features a king-sized bed as the primary sleeping arrangement. King Rooms are known for their spacious and comfortable design, making them a popular choice for couples, business travelers, or anyone seeking a more luxurious and restful hotel stay.</p>

        <a href="#" className="card-link">

          Learn More

        </a>

      </div>

    </div>

    <div className="card">

      <img

        src="https://www.kabayanhotel.com.ph/wp-content/uploads/2016/02/kabayan-standardroom-01.jpg"

        alt="Card Image"

        className="card-image"

      />

      <div className="card-content">

        <h3 className="card-title">Standard Room</h3>

        <p className="card-text">A "Standard Room" in a hotel is a basic and commonly offered type of accommodation. It is typically the most affordable room option available in a hotel and provides essential amenities for a comfortable stay.</p>

        <a href="#" className="card-link">

          Learn More

        </a>

      </div>

    </div>

    <div className="card">

      <img

        src="https://img.freepik.com/premium-photo/high-end-clean-atmospheric-hotel-rooms_149197-85.jpg?w=826"

        alt="Card Image"

        className="card-image"

      />

      <div className="card-content">

        <h3 className="card-title">Luxury</h3>

        <p className="card-text">A "Luxury Room" in a hotel is a premium and high-end accommodation option that offers guests an exceptional level of comfort, convenience, and luxury. These rooms are designed to provide a superior and indulgent experience for travelers who are willing to pay a premium for their stay. </p>

        <a href="#" className="card-link">

          Learn More

        </a>

      </div>

    </div>

    <div className="card">

      <img

        src="https://cf.bstatic.com/xdata/images/hotel/max1024x768/416133441.jpg?k=aac9e8919ecf73ad118d8e79b4f21208dceb646e411771346ced38a6da9c1061&o=&hp=1"

        alt="Card Image"

        className="card-image"

      />

      <div className="card-content">

        <h3 className="card-title">Dormitory</h3>

        <p className="card-text">A "Dormitory Room" in hotels is a unique type of accommodation that differs significantly from traditional hotel rooms. It is designed to cater to budget-conscious travelers, backpackers, or groups of people who are looking for affordable lodging options.</p>

        <a href="#" className="card-link">

          Learn More

        </a>

      </div>

    </div>

    </div>

    {/* <Footer/> */}
    <Footer/>

    </div>
    
    </>

  );

}

 

export default Home;
