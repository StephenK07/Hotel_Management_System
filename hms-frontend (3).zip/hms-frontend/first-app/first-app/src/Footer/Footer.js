import React from 'react';
import "../Footer/footer.css";
function Footer() {
    return (
<>
<footer>
  <div class="copyright text-center">
    Copyright &copy; 2023 <span>Hotel Management System</span>
  </div>
</footer>
</>
  
    );
}

export default Footer;