const Person = (props) =>{
    return(
        <>
          <h3>FirstName: {props.firstName}</h3>
          <h3>LastName: {props.lastName}</h3>
          <h3>Age: {props.age}</h3>
        </>
    )
};

export default Person;