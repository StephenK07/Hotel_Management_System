
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./addroom.css";
 
function Addroom() {
  const [roomData, setRoomData] = useState({
    roomNo: "",
    roomType: "",
    roomRent: "",
    roomsAvailable: "",
  });
  const [existingRooms, setExistingRooms] = useState([]);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
 
  useEffect(() => {
    const fetchExistingRooms = async () => {
      try {
        const response = await axios.get("http://localhost:8081/room/AllRooms");
        setExistingRooms(response.data.map((room) => room.roomNo));
      } catch (error) {
        console.error("Error fetching existing rooms:", error);
      }
    };
    fetchExistingRooms();
  }, []);
 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setRoomData({ ...roomData,
     [name]: value,
    });
  };
 
  const handleSubmit = async () => {
    const validationErrors = {};
 
    if (!roomData.roomNo) {
      validationErrors.roomNo = "Room number is required.";
    } else if (!/^\d+$/.test(roomData.roomNo)) {
      validationErrors.roomNo = "Room number must be a numeric value.";
    }
 
    if (!roomData.roomType) {
      validationErrors.roomType = "Room type is required.";
    } else if (/^\d+$/.test(roomData.roomType)) {
      validationErrors.roomType = "Room type must be a string.";
    }
 
    if (!roomData.roomRent || !/^\d+$/.test(roomData.roomRent)) {
      validationErrors.roomRent = "Room rent must be a numeric value.";
    }
 
    if (!["true", "false"].includes(roomData.roomsAvailable)) {
      validationErrors.roomsAvailable = "Rooms available must be 'true' or 'false'.";
    }
 
    setErrors(validationErrors);
 
    if (Object.keys(validationErrors).length > 0) {
      return;
    }
 
    try {
      if (existingRooms.includes(parseInt(roomData.roomNo))) {
        alert("Room already exists");
      } else {
        await axios.post("http://localhost:8081/room/addroom", roomData).then((response) => {
          navigate("/viewrooms");
        });
      }
    } catch (error) {
      console.error("Error adding room:", error);
    }
  };
 
  const handleCancel = () => {
    navigate("/viewrooms");
  };
 
  return (
    <div className="add-room-container-custom">
      <div className="add-room-form-custom">
        <h2>Add Room</h2>
        <form>
          <div className="form-group">
            <label htmlFor="roomNo">Room Number</label>
            <input
              type="text"
              name="roomNo"
              value={roomData.roomNo}
              onChange={handleInputChange}
              className={errors.roomNo ? "error" : ""}
            />
            {errors.roomNo && <div className="error-message">{errors.roomNo}</div>}
          </div>
          <div className="form-group">
            <label htmlFor="roomType">Room Type</label>
            <input
              type="text"
              name="roomType"
              value={roomData.roomType}
              onChange={handleInputChange}
              className={errors.roomType ? "error" : ""}
            />
            {errors.roomType && <div className="error-message">{errors.roomType}</div>}
          </div>
          <div className="form-group">
            <label htmlFor="roomRent">Room Rent</label>
            <input
              type="text"
              name="roomRent"
              value={roomData.roomRent}
              onChange={handleInputChange}
            />
            {errors.roomRent && <div className="error-message">{errors.roomRent}</div>}
          </div>
          <div className="form-group">
            <label htmlFor="roomsAvailable">Rooms Available</label>
            <input
              type="text"
              name="roomsAvailable"
              value={roomData.roomsAvailable}
              onChange={handleInputChange}
            />
            {errors.roomsAvailable && (
              <div className="error-message">{errors.roomsAvailable}</div>
            )}
          </div>
          <div className="button-group">
            <div className="button-container">
              <button type="button" onClick={handleSubmit}>
                Submit
              </button>
            </div>
            <div className="button-container">
              <button type="button" onClick={handleCancel}>
                Cancel
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
 
export default Addroom;
 