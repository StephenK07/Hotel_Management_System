
import React, { useState } from 'react';

import { Link, useLocation, useNavigate } from 'react-router-dom';

import { MdAccountCircle } from 'react-icons/md';

import './Navbar.css';

 

function Navbar() {

  const location = useLocation();

  const navigate = useNavigate();

 

  const isHomeRoute = location.pathname === '/';

  const isSignInRoute = location.pathname === '/login';

  const isSignUpRoute = location.pathname === '/SignUp';

  const isManagerHomeRoute = location.pathname === '/ManagerHome';

  const isOwnerHomeRoute = location.pathname === '/owner';

  const isReceptionHomeRoute = location.pathname === '/reception';

 

  const [profileOpen, setProfileOpen] = useState(false);

 

  const toggleProfile = () => {

    setProfileOpen(!profileOpen);

  };

 

  // Determine the user's role (you need to implement your own logic for this)

  // You can store the role in a state variable, Redux, or wherever it's available

  // This is a placeholder for demonstration purposes.

 

  const userRole = localStorage.getItem('userRole');

 

  let homeLink = '/';

  if (userRole === 'ROLE_OWNER') {

    homeLink = '/owner';

  } else if (userRole === 'ROLE_MANAGER') {

    homeLink = '/ManagerHome';

  } else if (userRole === 'ROLE_RECEPTIONIST') {

    homeLink = '/reception';

  }

 

  return (

    <nav>

      <ul className="nav-list">

        <li className="nav-item">

          <Link to="/">Home</Link>

        </li>

        <li className="nav-item">

          <Link to="/contact">Contact Us</Link>

        </li>

        <li className="nav-item">

          <Link to="/about">About Us</Link>

        </li>

      </ul>

 

      <center>

        <div className='hotel-name'>

          GALAXY LUXURY HOTEL
        </div>

      </center>

 

      <div className="auth-buttons">

        {isHomeRoute && (

          <>

            <Link to="/login" className="auth-button">

              Sign In

            </Link>

            {/* <Link to="/SignUp" className="auth-button">

              Sign Up

            </Link> */}

          </>

        )}

        {isSignInRoute && (

          <Link to="/SignUp" className="auth-button">

            Sign Up

          </Link>

        )}

        {isSignUpRoute && (

          <Link to="/login" className="auth-button">

            Sign In

          </Link>

        )}

      </div>

 

      {isManagerHomeRoute && (

        <div className="profile-icon-container">

          <MdAccountCircle size={24} onClick={toggleProfile} />

          {profileOpen && (

            <div className="profile-links">

              <Link to="/viewrooms">Rooms</Link>

              {/* <Link to="/manager/staff">Staff</Link> */}

              { <Link to="/ManagerReservation">Reservations</Link> }

              {/* <Link to="/inventory">Inventory</Link> */}

              <Link to='/'>Logout</Link>

            </div>

          )}

        </div>

      )}

 

      {isOwnerHomeRoute && (

        <div className="profile-icon-container">

          <MdAccountCircle size={24} onClick={toggleProfile} />

          {profileOpen && (

            <div className="profile-links">

              <Link to="/owner/managerinfo">Manager Info</Link>

              {/* { <Link to="/owner/inventory">Inventory Info</Link> } */}

              <Link to='/'>Logout</Link>

            </div>

          )}

        </div>

      )}

 

      {isReceptionHomeRoute && (

        <div className="profile-icon-container">

          <MdAccountCircle size={24} onClick={toggleProfile} />

          {profileOpen && (

            <div className="profile-links">

              <Link to="/viewguests">Guests</Link>

              <Link to="/rooms">Rooms</Link>

              <Link to="/viewreservation">Reservations</Link>

              <Link to='/'>Logout</Link>

            </div>

          )}

        </div>

      )}

    </nav>

  );

}

 

export default Navbar;