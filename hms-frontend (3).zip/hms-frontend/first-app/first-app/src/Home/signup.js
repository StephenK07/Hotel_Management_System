import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import './signup.css';

const Signup = () => {
  const [formData, setFormData] = useState({
    username: '',
    firstName: '',
    lastName: '',
    password: '',
    mobileNumber: '',
    email: '',
    role: '',
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Perform client-side validation here
    const validationErrors = {};
    if (!formData.username) {
      validationErrors.username = 'Username is required.';
    }
    if (!formData.firstName) {
      validationErrors.firstName = 'First name is required.';
    }
    if (!formData.lastName) {
      validationErrors.lastName = 'Last name is required.';
    }
    if (!formData.password) {
      validationErrors.password = 'Password is required.';
    }
    if (!formData.mobileNumber.match(/^[6-9]\d{9}$/)) {
      validationErrors.mobileNumber = 'Mobile number must start with 6, 7, 8, or 9 and have a maximum of 10 digits.';
    }
    if (!formData.email.match(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/)) {
      validationErrors.email = 'Please enter a valid email address.';
    }

    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      // Send the data to your backend using axios or your preferred method
      try {
        await axios.post('http://localhost:9095/auth/addNewUser', formData).then(response=>{
            console.log(response.data);
            alert(`${response.data}`)
            navigate('/login');

        })
        // Handle success, e.g., redirect to login page
      } catch (error) {
        // Handle errors, e.g., display an error message
       
        console.error('Error:', error);
        alert(error.response.data.message);
      }
    }
  };

  return (
    <div className="signup-container">
     
      <form className="signup-form" onSubmit={handleSubmit}>
        <div className="form-group">
        <h2>Sign Up</h2>
          <label>Username:</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
          />
          {errors.username && <div className="error">{errors.username}</div>}
        </div>
        <div className="form-group">
          <label>First Name:</label>
          <input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
          />
          {errors.firstName && <div className="error">{errors.firstName}</div>}
        </div>
        <div className="form-group">
          <label>Last Name:</label>
          <input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
          />
          {errors.lastName && <div className="error">{errors.lastName}</div>}
        </div>
        <div className="form-group">
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
          {errors.password && <div className="error">{errors.password}</div>}
        </div>
        <div className="form-group">
          <label>Mobile Number:</label>
          <input
            type="text"
            name="mobileNumber"
            value={formData.mobileNumber}
            onChange={handleChange}
          />
          {errors.mobileNumber && <div className="error">{errors.mobileNumber}</div>}
        </div>
        <div className="form-group">
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
          {errors.email && <div className="error">{errors.email}</div>}
        </div>
        <div className="form-group">
          <label>Role:</label>
          <select name="role" value={formData.role} onChange={handleChange}>
          <option value="ROLE" >ROLE</option>
            <option value="ROLE_MANAGER">ROLE_MANAGER</option>
            <option value="ROLE_RECEPTIONIST">ROLE_RECEPTIONIST</option>
          </select>
        </div>
        <div className="button-group">
          <button type="submit">Sign Up</button>
        </div>
      </form>
    </div>
  );
};

export default Signup;
