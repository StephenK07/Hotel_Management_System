
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import './login.css';
 
function Login() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
 
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false); // State to manage password visibility
 
  const [validationErrors, setValidationErrors] = useState({
    username: '',
    password: '',
  });
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    // Clear validation error for the field being updated
    setValidationErrors({ ...validationErrors, [name]: '' });
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(formData);
    // Basic validation for non-empty fields
    if (!formData.username) {
      setValidationErrors({ ...validationErrors, username: 'Username is required.' });
      return;
    }
    if (!formData.password) {
      setValidationErrors({ ...validationErrors, password: 'Password is required.' });
      return;
    }
 
    try {
      const response = await axios.post('http://localhost:9095/auth/signin', formData);
 
      console.log('Login successful:', response.data);
      const role = response.data.roles[0];
      console.log(role);
      if (role === 'ROLE_ADMIN') {
        navigate('/owner');
      } else if (role === 'ROLE_MANAGER') {
        navigate('/ManagerHome');
      } else if (role === 'ROLE_RECEPTIONIST') {
        navigate('/reception');
      }
    } catch (error) {
      if (error.response) {
        setError(error.response.data.message || 'An error occurred while logging in.');
      } else {
        setError('An error occurred while logging in.');
      }
    }
  };
 
  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>Login</h2>
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            name="username"
            id="username"
            value={formData.username}
            onChange={handleChange}
          />
          <span className="error">{validationErrors.username}</span>
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <div className="password-input">
            <input
              type={showPassword ? 'text' : 'password'}
              name="password"
              id="password"
              value={formData.password}
              onChange={handleChange}
 
             
            />
            <span
              className={`eye-icon ${showPassword ? 'visible' : ''}`}
              onClick={() => setShowPassword(!showPassword)}
            >
              👁️
            </span>
          </div>
          <span className="error">{validationErrors.password}</span>
        </div>
        {error && <p className="error-message">{error}</p>}
        <button type="submit">Login</button>
        <p className="noaccount">
          Don't have an account? <Link to="/signup" className="signup-link" >Sign Up</Link>
        </p>
      </form>
    </div>
  );
}
 
export default Login;
 