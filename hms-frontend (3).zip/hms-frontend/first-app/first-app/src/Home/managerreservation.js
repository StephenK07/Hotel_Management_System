import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../Reception/viewreservation.css';
import { useNavigate } from 'react-router-dom';

function AllReservation() {
  const [reservations, setReservations] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch reservations from your API when the component loads
    axios
      .get('http://localhost:8082/reservation/viewAllReservations')
      .then((response) => {
        setReservations(response.data);
      })
      .catch((error) => {
        console.error('Error fetching reservations:', error);
      });
  }, []);

  const handleUpdate = (reservationId) => {
    // Implement your update logic here, e.g., navigate to an update page
    navigate(`/updateReservation/${reservationId}`);
  };
  // if (userRole === 'manager') {
  //   navigate('/ManagerHome');
  // } else if (userRole === 'receptionist') {
  //   navigate('/reception');
  // } 
  const handleDelete = async (reservationId) => {
    const confirmed = window.confirm('Are you sure you want to delete the reservation?');

    if (confirmed) {
      try {
        // Make an HTTP DELETE request to delete the room
        await axios.delete(`http://localhost:8082/reservation/deletereservation/${reservationId}`);
        // Update the room list by fetching data again
        const response = await axios.get('http://localhost:8082/reservation/viewAllReservations');
        setReservations(response.data);
      } catch (error) {
        console.error(`Error deleting reservation with reservationId ${reservationId}:`, error);
      }
    }
  };

  return (
    <div>
      <header>
        <div className="reser-main">
          <button className="back-button" onClick={() => navigate('/ManagerHome')}>Back</button>
          <center><h1 className="reser">Reservations</h1></center>
          
        </div>
      </header>

      <div className="reservation-card-container">
        {reservations.map((reservation) => (
          <div key={reservation.reservationId} className="reservation-card">
            <h3>Reservation ID: {reservation.reservationId}</h3>
            <p>Room Number: {reservation.roomNo}</p>
            <p>Guest ID: {reservation.guestId}</p>
            <p>Check-In Date: {reservation.checkInDate}</p>
            <p>Check-Out Date: {reservation.checkOutDate}</p>
            <p>Total Price:  ₹{reservation.totalPrice}</p>
            <button className="update-button" onClick={() => handleUpdate(reservation.reservationId)}>Update</button>
            <button className="delete-button" onClick={() => handleDelete(reservation.reservationId)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AllReservation;
