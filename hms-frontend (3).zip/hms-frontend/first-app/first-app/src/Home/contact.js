import React from 'react'
import './contact.css'

export default function Contact() {
  return (

    <div className='contact_container1 pavcontacttext'>
        <center>

        
        <h1 className='contact-us'><u>Contact Us</u></h1>
        <div className='contact_container2'>
          <div className='Contact_container3'>
            <h3>Phone Number:+91 1234567890</h3>
            <p>Incase the about number is not available, you can also contact us throught the below phone  number</p>
            <p>+91 6304920496</p>
            <p>Mail Id:hotelmanagement@gmail.com</p><br></br>
          </div>
          <div className="text-centre"><h1><u>Follow me on </u></h1>&emsp;<br></br>
            <h2>
                <a id="insta" href="https://www.instagram.com/pavan.in/" target="_blank" rel="noreferrer">Instagram</a>&emsp;
                <a id="face" href="https://www.facebook.com/pavan.amajala/" target="_blank" rel="noreferrer">Facebook</a>&emsp;
                <a id="link" href="https://www.linkedin.com/in/sri-ram-pavan-amajala-a31404192" target="_blank" rel="noreferrer">Linkedin</a>&emsp;
            </h2>
          </div>
        </div>
        </center>
      </div>

  )
}
