import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios';
import './updateroom.css';
import { useNavigate } from "react-router-dom";

function UpdateRoom() {
  const { roomNo } = useParams();
  const [errors, setErrors] = useState({});
  //const navigate = useNavigate();
  const [roomData, setRoomData] = useState({
    roomNo: '',
    roomType: '',
    roomRent: '',
    roomsAvailable: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    setRoomData({ ...roomData, [name]: value });
  };

  const handleUpdateRoom = async () => {
    const validationErrors = {};

    if (!roomData.roomType) {
      validationErrors.roomType = "Room type is required.";
    } else if (/^\d+$/.test(roomData.roomType)) {
      validationErrors.roomType = "Room type must be a string.";
    }

    if (!roomData.roomRent || !/^\d+$/.test(roomData.roomRent)) {
      validationErrors.roomRent = "Room rent must be a numeric value.";
    }

    if (!["true", "false"].includes(roomData.roomsAvailable)) {
      validationErrors.roomsAvailable = "Rooms available must be 'true' or 'false'.";
    }

    setErrors(validationErrors);
    const backendURL = 'http://localhost:8081/room'; 
    
    // Replace with your backend URL
    if (Object.keys(validationErrors).length > 0) {
      return;
    }
    try {

      const response = await axios.put(`${backendURL}/updateroom/${roomNo}`, roomData);
      console.log('Room updated:', response.data);
      alert("Room Updated Successfully!");
      // Handle success and update your UI or navigate to another page if needed
    } catch (error) {
      console.error('Error updating room:', error);
      // Handle error, e.g., display an error message to the user
    }
  };

  useEffect(() => {
    const fetchRoomData = async () => {
      try {
        const response = await axios.get(`http://localhost:8081/room/viewroom/${roomNo}`);
        setRoomData(response.data); // Assuming the API response has the same structure as roomData
      } catch (error) {
        console.error('Error fetching room data:', error);
        // Handle error, e.g., display an error message to the user
      }
    };

    fetchRoomData();
  }, [roomNo]);

  return (
    <div className="update-room-container-custom">
      <div className="update-room-form-custom">
        <h2>Update Room</h2>
        <form>
          <div className="form-group">
            <label htmlFor="roomNo">Room Number:</label>
            <input
              type="text"
              name="roomNo"
              value={roomData.roomNo}
              readOnly
      
            />
          </div>
          <div className="form-group">
            <label htmlFor="roomType">Room Type:</label>
            <input
              type="text"
              name="roomType"
              value={roomData.roomType}
              onChange={handleInputChange}
            />
             {errors.roomType && <div className="error-message">{errors.roomType}</div>}
          </div>
          <div className="form-group">
            <label htmlFor="roomRent">Room Rent:</label>
            <input
              type="text"
              name="roomRent"
              value={roomData.roomRent}
              onChange={handleInputChange}
            />
            {errors.roomRent && <div className="error-message">{errors.roomRent}</div>} 
          </div>
          <div className="form-group">
            <label htmlFor="roomsAvailable">Rooms Available:</label>
            <input
              type="text"
              name="roomsAvailable"
              value={roomData.roomsAvailable}
              //onChange={handleInputChange}
              readOnly
            />
            {errors.roomsAvailable && <div className="error-message">{errors.roomsAvailable}</div>} 
          </div>
          <div className="button-group">
            <button type="button" onClick={handleUpdateRoom}>
              Update Room
            </button>
            <Link to="/viewrooms" className="back-link">Back to Room List</Link>
          </div>
        </form>
      </div>
      
    </div>
  );
}

export default UpdateRoom;
