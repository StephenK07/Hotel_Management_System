import React from "react";
import Navbar from "./Navbar";
import './manager.css';
function ManagerHome(){
    return(
        
        <div>
            <div className="tejuu">
            <Navbar></Navbar>
            
            <div >
            <center>
            <h1 className="tej">Welcome to manager</h1>
            </center>
            </div>
            </div>
           
        
            <div className="manager-image">
                <center>
                <img className="pic" src="https://media.istockphoto.com/id/1191193092/photo/hotel-receptionist-assisting-guest-for-checking-in.jpg?s=612x612&w=0&k=20&c=qJi8yiwZoTPr1gjnKmPH9-kPRwVzz-3sW-wm8aLfTZo=" alt=""/>
                </center>
            </div>
            
            
            
        </div>
    );
}

export default ManagerHome;

   