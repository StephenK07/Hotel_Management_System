import React, { useState, useEffect } from 'react';
import './allpayments.css';
import { useNavigate } from 'react-router-dom';

function AllPayments() {
  const [payments, setPayments] = useState([]);
  const [reservationId, setReservationId] = useState('');
  const [guestId, setGuestId] = useState('');
  const [roomNo, setRoomNo] = useState(''); // Add roomNo state

  useEffect(() => {
    // Retrieve payments from local storage
    const storedPayments = JSON.parse(localStorage.getItem('payments')) || [];
    setPayments(storedPayments);

    // Retrieve reservationId and guestId from local storage
    const storedReservationId = localStorage.getItem('reservationId') || '';
    const storedGuestId = localStorage.getItem('guestId') || '';
    const storedRoomNo = localStorage.getItem('roomNo') || ''; // Retrieve roomNo

    // Use a unique key for the latest payment entry (e.g., timestamp)
    const latestPaymentKey = 'payment_' + Date.now();

    // Check if the latest payment key exists in local storage
    const latestPayment = JSON.parse(localStorage.getItem(latestPaymentKey));

    // If the latest payment exists, update the reservationId and guestId
    if (latestPayment) {
      setReservationId(latestPayment.reservationId);
      setGuestId(latestPayment.guestId);
      setRoomNo(storedRoomNo); // Set roomNo from local storage
    }
  }, []);
  const navigate = useNavigate();

  return (
    <div>
      <h2 className="allpay">All Payments</h2>
      <button className="back-button" onClick={() => navigate('/rooms')}>Back</button>
      
      <div className="all-payments-container">
        <table>
          <thead>
            <tr>
              <th>Row Number</th>
              <th>Payment ID</th>
              <th>Order ID</th>
              <th>Amount</th>
              <th>PaymentStatus</th>
              {/* <th>RoomNo</th> Add RoomNo column */}
            </tr>
          </thead>
          <tbody>
            {payments.map((payment, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{payment.razorpay_payment_id}</td>
                <td>{payment.razorpay_order_id}</td>
                <td>{payment.razorpay_amount}</td>
                <td style={{ color: 'green' }}>Paid!</td>
                {/* <td>{roomNo}</td> Render roomNo here */}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AllPayments;

