import React, { useState, useEffect } from "react";
import axios from "axios";
import './availableroom.css';
import { useNavigate } from "react-router-dom";

function AvailableRooms() {
  const [rooms, setRooms] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:8081/room/viewAllRooms");
        setRooms(response.data);
      } catch (error) {
        console.error("Error fetching rooms:", error);
      }
    };

    fetchData(); // Fetch the room data when the component is mounted
  }, []);

  const filteredRooms = rooms.filter((room) =>
    room.roomType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  

  const navigateToCreate=(e)=>{
    e.preventDefault();
    navigate('/add');
  }
  const navigating=(e)=>{
    e.preventDefault();
    navigate('/viewreservation');
  }

 

  return (
    <div>
      <center><h1>Available Rooms !!</h1></center>
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search by room type"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
         <button onClick={navigateToCreate} className="add-room-button">Add Reservation</button>
         
        <button onClick={navigating} className="view-room-button">View Reservation</button>
        
      </div>
      <div className="room-cards-container">
        {filteredRooms.map((room) => (
          <div key={room.roomNo} className="room-card">
            <h3>Room Number: {room.roomNo}</h3>
            <p>Room Type: {room.roomType}</p>
            <p>Room Rent: {room.roomRent}</p>
            <p>Rooms Available: {room.roomsAvailable }</p>
           
            
          </div>
        ))}
      </div>
    </div>
  );
}

export default AvailableRooms;
