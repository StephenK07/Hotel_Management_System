import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import './updateguest.css'; // Import your CSS file
import { useNavigate } from 'react-router-dom';

function UpdateGuest() {
  const { guestId } = useParams(); // Get the guestId from the URL path
  const navigate = useNavigate();
  const [guestData, setGuestData] = useState({
    name: '',
    mobileNumber: '',
    email: '',
    gender: '',
    address: '',
  });

  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    const fetchGuestData = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/guest/viewguest/${guestId}`);
        const guest = response.data;
        setGuestData({
          name: guest.name,
          mobileNumber: guest.mobileNumber,
          email: guest.email,
          gender: guest.gender,
          address: guest.address,
        });
      } catch (error) {
        console.error(`Error fetching guest with guestId ${guestId}:`, error);
      }
    };

    fetchGuestData();
  }, [guestId]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setGuestData({ ...guestData, [name]: value });

    // Clear the validation error when the user types
    setValidationErrors({ ...validationErrors, [name]: '' });
  };

  const validateForm = () => {
		const errors = {};

		if (!guestData.name) {
			errors.name = "Name is required.";
		} else if (!guestData.name.match(/^[A-Za-z ]+$/)) {
			errors.name = "Name should contain only alphabets and spaces.";
		}

		if (!guestData.mobileNumber) {
			errors.mobileNumber = "Mobile number is required.";
		} else if (!/^[6789]\d{9}$/.test(guestData.mobileNumber)) {
			errors.mobileNumber =
				"Mobile number should contain 10 digits and start with 6, 7, 8, or 9.";
		}

		if (!guestData.email) {
			errors.email = "Email is required.";
		} else if (!/^[a-zA-Z]+@gmail\.com$/.test(guestData.email)) {
			errors.email = "Invalid email format. Please use a Gmail address.";
		}

		if (!guestData.gender) {
			errors.gender = "Gender is required.";
		} else if (
			!["male", "female", "others"].includes(guestData.gender.toLowerCase())
		) {
			errors.gender = "Gender should be male, female, or others.";
		}

		if (!guestData.address) {
			errors.address = "Address is required.";
		}

		setValidationErrors(errors);

		// Return true if there are no errors, indicating the form is valid

		return Object.keys(errors).length === 0;
	};

  const handleUpdateGuest = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      // Send the updated guest data to the backend for saving
      await axios.put(`http://localhost:8080/guest/updateguest/${guestId}`, guestData);

      alert('Guest updated successfully.');
      navigate('/viewguests');


      // Optionally, navigate to another page or update the UI as needed
    } catch (error) {
      console.error(`Error updating guest with guestId ${guestId}:`, error);
      alert('An error occurred while updating the guest.');
    }
  };

  return (
    <div className="update-guest-container">
      <h2>Update Guest</h2>
      <form>
        <div>
          <label>Name:</label>
          <input type="text" name="name" value={guestData.name} onChange={handleInputChange} />
          <span className="error">{validationErrors.name}</span>
        </div>
        <div>
          <label>Mobile Number:</label>
          <input
            type="text"
            name="mobileNumber"
            value={guestData.mobileNumber}
            onChange={handleInputChange}
          />
          <span className="error">{validationErrors.mobileNumber}</span>
        </div>
        <div>
          <label>Email:</label>
          <input type="text" name="email" value={guestData.email} onChange={handleInputChange} />
          <span className="error">{validationErrors.email}</span>
        </div>
        <div>
          <label>Gender:</label>
          <input type="text" name="gender" value={guestData.gender} onChange={handleInputChange} />
          <span className="error">{validationErrors.gender}</span>
        </div>
        <div>
          <label>Address:</label>
          <input type="text" name="address" value={guestData.address} onChange={handleInputChange} />
          <span className="error">{validationErrors.address}</span>
        </div>
        <button onClick={handleUpdateGuest}>Update Guest</button>
      </form>
    </div>
  );
}

export default UpdateGuest;
