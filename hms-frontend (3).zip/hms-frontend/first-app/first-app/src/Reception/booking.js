import React, { useState } from 'react';
import axios from 'axios';
import './booking.css'; // Import your CSS file
import { useNavigate } from 'react-router-dom'; // Import useNavigate

function BookingPage() {
  const [reservationId, setReservationId] = useState('');
  const [roomNo, setRoomNo] = useState('');
  const [checkInDate, setCheckInDate] = useState('');
  const [checkOutDate, setCheckOutDate] = useState('');
  const [totalPrice, setTotalPrice] = useState('');

  const navigate = useNavigate(); // Initialize useNavigate

  const handleReservationIdChange = (e) => {
    setReservationId(e.target.value);
  };

  const fetchReservationDetails = async () => {
    try {
      const response = await axios.get(`http://localhost:8082/reservation/viewreservation/${reservationId}`);
      const reservation = response.data;

      setRoomNo(reservation.roomNo);
      setCheckInDate(reservation.checkInDate);
      setCheckOutDate(reservation.checkOutDate);
      setTotalPrice(reservation.totalPrice);
    } catch (error) {
      console.error('Error fetching reservation details:', error);
      alert('Give a valid ReservationId');
    }
  };

  // Function to navigate to the Payment Page
  const handlePayment = () => {
    if(!reservationId) {
        alert("Give a valid ReservationId");
    } else {
        navigate("/payment", { state : { totalPrice: totalPrice}});
    }
    // You can navigate to the payment page with total price as state
   
  };

  return (
    <div className="booking-container">
      <h1 className="booking-title">Booking Page</h1>
      <div className="form-group">
        <label className="booking-label">Reservation ID:</label>
        <input
          type="text"
          value={reservationId}
          onChange={handleReservationIdChange}
          className="booking-input"
        />
        <button className="booking-button" onClick={fetchReservationDetails}>Fetch Details</button>
      </div>
      <div className="form-group">
        <label className="booking-label">Room Number:</label>
        <input
          type="text"
          value={roomNo}
          readOnly
          className="booking-input"
        />
      </div>
      <div className="form-group">
        <label className="booking-label">Check-In Date:</label>
        <input
          type="date"
          value={checkInDate}
          readOnly
          className="booking-input booking-checkin"
        />
      </div>
      <div className="form-group">
        <label className="booking-label">Check-Out Date:</label>
        <input
          type="date"
          value={checkOutDate}
          readOnly
          className="booking-input booking-checkout"
        />
      </div>
      <div className="form-group">
        <label className="booking-label">Total Price:</label>
        <input
          type="text"
          value={totalPrice}
          readOnly
          className="booking-input"
        />
      </div>
      <button className="booking-button" onClick={handlePayment}>Pay</button>
    </div>
  );
}

export default BookingPage;
