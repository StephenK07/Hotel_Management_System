import React from "react";

import './reception.css';

import Navbar from "../Home/Navbar";
function ReceptionHome(){
    return(
        
        <div>
            <div className="tejuu">
            <Navbar></Navbar>
            
            <div >
            <center>
            <h1 className="tej">Welcome to Reception</h1>
            </center>
            </div>
            </div>
           


            
            
            <div>
                <center>
                <img className="pic" src="https://cdn.pixabay.com/photo/2021/02/03/00/10/receptionists-5975962_1280.jpg" alt="ReceptionImage"/>;
                </center>
            </div>

            
            
        </div>
    );
}

export default ReceptionHome;