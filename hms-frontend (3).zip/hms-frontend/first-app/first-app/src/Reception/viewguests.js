import React, { useState, useEffect } from "react";
import axios from "axios";
import './viewguests.css';
import { useNavigate } from "react-router-dom";

function ViewGuests() {
  const [guests, setGuests] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:8080/guest/viewall");
        setGuests(response.data);
      } catch (error) {
        console.error("Error fetching guests:", error);
      }
    };

    fetchData(); // Fetch the guest data when the component is mounted
  }, []);

  const filteredGuests = guests.filter((guest) =>
    guest.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUpdate = (guestId) => {
    // Redirect to the update page for the selected guest
    navigate(`/updateguest/${guestId}`);
  };

  const navigateToCreate = (e) => {
    e.preventDefault();
    navigate('/addguest');
  };
  const handleBackToHome=()=>{
    navigate('/reception');
  }

  const handleDelete = async (guestId) => {
    const confirmed = window.confirm("Are you sure you want to delete the guest?");

  if (confirmed) {
    try {
      // Make an HTTP DELETE request to delete the guest
      await axios.delete(`http://localhost:8080/guest/deleteguest/${guestId}`);

      
      // Update the guest list by fetching data again
      const response = await axios.get("http://localhost:8080/guest/viewall");
      setGuests(response.data);
    }
    catch (error) {
      console.error(`Error deleting guest with guestId ${guestId}:`, error);
    }}
  };

  return (
    <div>
      <center><h1>Guest List</h1></center>
      <div className="search-bar">
      <button onClick={handleBackToHome} className="back-button">Back</button>
        <input
          type="text"
          placeholder="Search by name"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button onClick={navigateToCreate} className="add-guest-button">Add Guest</button>
      </div>
      <div className="guest-cards-container">
        {filteredGuests.map((guest) => (
          <div key={guest.guestId} className="guest-card">
            <h3>Guest ID: {guest.guestId}</h3>
            <p>Name: {guest.name}</p>
            <p>Mobile Number: {guest.mobileNumber}</p>
            <p>Email: {guest.email}</p>
            <p>Gender: {guest.gender}</p>
            <p>Address: {guest.address}</p>
            <button className="update-button" onClick={() => handleUpdate(guest.guestId)}>Update</button>
            <button className="delete-button" onClick={() => handleDelete(guest.guestId)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ViewGuests;
