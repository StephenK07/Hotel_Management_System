import React, { useState } from "react";
import axios from "axios";
import "./AddGuest.css";
import { useNavigate } from "react-router-dom";
 
function AddGuest() {
  const [guestData, setGuestData] = useState({
    name: "",
    mobileNumber: "",
    email: "",
    gender: "", // Changed gender to be a string
    address: "",
  });
 
  const [validationErrors, setValidationErrors] = useState({});
  const [responseMessage, setResponseMessage] = useState("");
  const navigate = useNavigate();
 
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setGuestData({ ...guestData, [name]: value });
    setValidationErrors({ ...validationErrors, [name]: "" });
  };
 
  const validateForm = () => {
    const errors = {};
 
    if (!guestData.name) {
      errors.name = "Name is required.";
    } else if (!guestData.name.match(/^[A-Za-z ]+$/)) {
      errors.name = "Name should contain only alphabets and spaces.";
    }
 
    if (!guestData.mobileNumber) {
      errors.mobileNumber = "Mobile number is required.";
    } else if (!/^[6789]\d{9}$/.test(guestData.mobileNumber)) {
      errors.mobileNumber =
        "Mobile number should contain 10 digits and start with 6, 7, 8, or 9.";
    }
 
    if (!guestData.email) {
      errors.email = "Email is required.";
    } else if (!/^[a-zA-Z]+@gmail\.com$/.test(guestData.email)) {
      errors.email = "Invalid email format. Please use a Gmail address.";
    }
 
    if (!guestData.gender) {
      errors.gender = "Gender is required.";
    }
 
    if (!guestData.address) {
      errors.address = "Address is required.";
    }
 
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };
 
  const handleAddGuest = async (e) => {
    e.preventDefault();
 
    if (!validateForm()) {
      return;
    }
 
    try {
      const response = await axios.post(
        "http://localhost:8080/guest/addguest",
        guestData
      );
 
      if (`${response.data}`.includes("Email already exists!")) {
        alert("Email already exists, please change the email.");
      } else {
        alert("Guest added successfully.");
        navigate("/viewguests");
      }
    } catch (error) {
      console.error("Error adding guest:", error);
      alert(error.response.data.message);
    }
  };
 
  // Define gender options
  const genderOptions = ["Male", "Female", "Others"];
 
  return (
    <div className="add-guest-container">
      <h2>Add Guest</h2>
 
      <form>
        <div>
          <label>Name:</label>
          <input type="text" name="name" value={guestData.name} onChange={handleInputChange} />
          <span className="error">{validationErrors.name}</span>
        </div>
 
        <div>
          <label>Mobile Number:</label>
          <input type="text" name="mobileNumber" value={guestData.mobileNumber} onChange={handleInputChange} />
          <span className="error">{validationErrors.mobileNumber}</span>
        </div>
 
        <div>
          <label>Email:</label>
          <input type="text" name="email" value={guestData.email} onChange={handleInputChange} />
          <span className="error">{validationErrors.email}</span>
        </div>
 
        <div>
          <label>Gender:</label>
          <select name="gender" value={guestData.gender} onChange={handleInputChange}>
            <option value="">Select Gender</option>
            {genderOptions.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
          <span className="error">{validationErrors.gender}</span>
        </div>
 
        <div>
          <label>Address:</label>
          <input type="text" name="address" value={guestData.address} onChange={handleInputChange} />
          <span className="error">{validationErrors.address}</span>
        </div>
 
        <button onClick={handleAddGuest}>Add Guest</button>
      </form>
 
      <div className="response-message">{responseMessage}</div>
    </div>
  );
}
 
export default AddGuest;
 