import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './addreservation.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

function AddReservation() {
  const [reservationData, setReservationData] = useState({
    roomNo: '',
    guestId: '',
    checkInDate: null,
    checkOutDate: null,
    totalPrice: 0,
  });
  const [roomRent, setRoomRent] = useState(0);
  const [validationErrors, setValidationErrors] = useState({});
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    if (name === 'checkInDate') {
      if (
        reservationData.checkOutDate &&
        new Date(value) >= reservationData.checkOutDate
      ) {
        setReservationData({
          ...reservationData,
          [name]: new Date(value),
          checkOutDate: null,
        });
      } else {
        setReservationData({ ...reservationData, [name]: new Date(value) });
      }
    } else if (name === 'checkOutDate') {
      if (
        reservationData.checkInDate &&
        new Date(value) <= reservationData.checkInDate
      ) {
        setReservationData({
          ...reservationData,
          [name]: new Date(value),
          checkInDate: null,
        });
      } else {
        setReservationData({ ...reservationData, [name]: new Date(value) });
      }
    } else {
      setReservationData({ ...reservationData, [name]: value });
    }

    setValidationErrors({ ...validationErrors, [name]: '' });
  };

  const calculateTotalPrice = () => {
    if (reservationData.checkInDate && reservationData.checkOutDate) {
      const checkIn = reservationData.checkInDate;
      const checkOut = reservationData.checkOutDate;
      const timeDiff = Math.abs(checkOut - checkIn);
      const totalDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
      const totalPrice = roomRent * totalDays;
      setReservationData({ ...reservationData, totalPrice });
    }
  };

  const handleAddReservation = (e) => {
    e.preventDefault();
    const errors = {};

    if (!reservationData.roomNo) {
      errors.roomNo = 'Room number is required.';
    }

    if (!reservationData.guestId) {
      errors.guestId = 'Guest ID is required.';
    }

    if (!reservationData.checkInDate) {
      errors.checkInDate = 'Check-in date is required.';
    }

    if (!reservationData.checkOutDate) {
      errors.checkOutDate = 'Check-out date is required.';
    }

    if (
      reservationData.checkInDate &&
      reservationData.checkOutDate &&
      reservationData.checkInDate.getTime() === reservationData.checkOutDate.getTime()
    ) {
      errors.checkOutDate = 'Check-out date cannot be the same as check-in date.';
    }

    setValidationErrors(errors);

    if (Object.keys(errors).length > 0) {
      return;
    }

    try {
      const formattedCheckInDate = formatDate(reservationData.checkInDate);
      const formattedCheckOutDate = formatDate(reservationData.checkOutDate);

      const dataForBackend = {
        ...reservationData,
        checkInDate: formattedCheckInDate,
        checkOutDate: formattedCheckOutDate,
      };

      axios
        .post('http://localhost:8082/reservation/addreservation', dataForBackend)
        .then((response) => {
          if (`${response.data}`.includes('Room is already filled')) {
            alert('Room is already filled');
          }  else if(`${response.data}`.includes('Room is not present with')){
            alert('Room is not present,Make sure that the room should be available.')
         }else {
            // Retrieve existing reservation and guest details from local storage
            const existingReservationId = localStorage.getItem('reservationId');
            const existingGuestId = localStorage.getItem('guestId');

            // Store the new reservation and guest details
            localStorage.setItem('reservationId', response.data.reservationId);
            localStorage.setItem('guestId', reservationData.guestId);

          
              // If there was no existing reservation ID, navigate to payment
              // navigate('/payment', { state: { totalPrice: reservationData.totalPrice } });
              navigate('/viewreservation');
           
          }
        });
    } catch (error) {
      console.error('Error adding reservation:', error);
    }
  };

  useEffect(() => {
    axios
      .get(`http://localhost:8081/room/viewroom/${reservationData.roomNo}`)
      .then((response) => {
        setRoomRent(response.data.roomRent);
      })
      .catch((error) => {
        console.error('Error fetching room rent:', error);
      });
  }, [reservationData.roomNo]);

  const formatDate = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  return (
    <div className="add-reservation-container">
      <h2>Add Reservation</h2>
      <form>
        <div>
          <label>Room Number:</label>
          <input
            type="text"
            name="roomNo"
            value={reservationData.roomNo}
            onChange={handleInputChange}
          />
          <span className="error">{validationErrors.roomNo}</span>
        </div>
        <div>
          <label>Guest ID:</label>
          <input
            type="text"
            name="guestId"
            value={reservationData.guestId}
            onChange={handleInputChange}
          />
          <span className="error">{validationErrors.guestId}</span>
        </div>
        <div>
          <label>Check-In Date:</label>
          <DatePicker
            selected={reservationData.checkInDate}
            onChange={(date) => setReservationData({ ...reservationData, checkInDate: date })}
            minDate={new Date()}
            dateFormat="yyyy-MM-dd"
            className=" booking-checkin"
          />
          <span className="error">{validationErrors.checkInDate}</span>
        </div>
        <div>
          <label>Check-Out Date:</label>
          <DatePicker
            selected={reservationData.checkOutDate}
            onChange={(date) => setReservationData({ ...reservationData, checkOutDate: date })}
            onBlur={calculateTotalPrice}
            minDate={reservationData.checkInDate || new Date()}
            dateFormat="yyyy-MM-dd"
            className=" booking-checkout"
          />
          <span className="error">{validationErrors.checkOutDate}</span>
        </div>
        <div>
          <label>Room Rent:</label>
          <input type="text" value={roomRent} readOnly />
        </div>
        <div>
          <label>Total Price: </label>
          <input
            type="text"
            name="totalPrice"
            value={reservationData.totalPrice}
            readOnly
          />
        </div>
        <button onClick={handleAddReservation}>Book now</button>
      </form>
    </div>
  );
}

export default AddReservation;

