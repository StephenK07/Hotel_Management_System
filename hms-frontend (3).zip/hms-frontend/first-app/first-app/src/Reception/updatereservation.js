import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import './addreservation.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import 'font-awesome/css/font-awesome.min.css';
// import './viewreservation.css';

function UpdateReservation() {
  const { reservationId } = useParams();
  const navigate = useNavigate();
  const [reservationData, setReservationData] = useState({
    roomNo: '',
    guestId: '',
    checkInDate: null,
    checkOutDate: null,
    totalPrice: 0,
  });

  const [roomRent, setRoomRent] = useState(0);
  const [validationErrors, setValidationErrors] = useState({});

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setReservationData({ ...reservationData, [name]: value });

    // Clear the validation error when user types
    setValidationErrors({ ...validationErrors, [name]: '' });
  };

  const calculateTotalPrice = () => {
    if (reservationData.checkInDate && reservationData.checkOutDate) {
      const checkIn = reservationData.checkInDate;
      const checkOut = reservationData.checkOutDate;
      const timeDiff = Math.abs(checkOut - checkIn);
      const totalDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
      const totalPrice = roomRent * totalDays;
      setReservationData({ ...reservationData, totalPrice });
    }
  };

  const validateForm = () => {
    const errors = {};

    if (!reservationData.roomNo) {
      errors.roomNo = 'Room number is required.';
    }

    if (!reservationData.guestId) {
      errors.guestId = 'Guest ID is required.';
    }

    if (!reservationData.checkInDate) {
      errors.checkInDate = 'Check-in date is required.';
    }

    if (!reservationData.checkOutDate) {
      errors.checkOutDate = 'Check-out date is required.';
    }
    if (
 
      reservationData.checkInDate &&
 
      reservationData.checkOutDate &&
 
      reservationData.checkInDate.getTime() === reservationData.checkOutDate.getTime()
 
    ) {
 
      errors.checkOutDate = 'Check-out date cannot be the same as check-in date.';
 
    }
    setValidationErrors(errors);

    // Return true if there are no errors, indicating the form is valid
    return Object.keys(errors).length === 0;
  };

  const handleUpdateReservation = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    if (reservationData.checkInDate && reservationData.checkOutDate) 
    {     if (reservationData.checkOutDate < reservationData.checkInDate) 
      {       setValidationErrors({         ...validationErrors,         checkOutDate: 'Check-out date cannot be earlier than check-in date.', });  
           return;     }   }

           


    try {
      const formattedCheckInDate = formatDate(reservationData.checkInDate);
      const formattedCheckOutDate = formatDate(reservationData.checkOutDate);

      const dataForBackend = {
        ...reservationData,
        checkInDate: formattedCheckInDate,
        checkOutDate: formattedCheckOutDate,
      };

      const response = await axios.put(
        `http://localhost:8082/reservation/updatereservation/${reservationId}`,
        dataForBackend
      );

      if (response.data.includes('Room is already filled')) {
        alert('Room is already filled');
      } 
       else {
        alert('Reservation updated successfully');
      }

      navigate('/viewreservation');
    } catch (error) {
      console.error('Error updating reservation:', error);
      alert('An error occurred while updating the reservation.');
    }
  };

  useEffect(() => {
    axios
      .get(`http://localhost:8081/room/viewroom/${reservationData.roomNo}`)
      .then((response) => {
        setRoomRent(response.data.roomRent);
      })
      .catch((error) => {
        console.error('Error fetching room rent:', error);
      });
  }, [reservationData.roomNo]);

  useEffect(() => {
    const fetchReservationData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8082/reservation/viewreservation/${reservationId}`
        );
        const { roomNo, guestId, checkInDate, checkOutDate, totalPrice } = response.data;

        const checkInDateObj = new Date(checkInDate);
        const checkOutDateObj = new Date(checkOutDate);

        setReservationData({
          roomNo,
          guestId,
          checkInDate: checkInDateObj,
          checkOutDate: checkOutDateObj,
          totalPrice,
        });
      } catch (error) {
        console.error('Error fetching reservation data:', error);
      }
    };

    fetchReservationData();
  }, [reservationId]);

  const formatDate = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  return (
    <div className="add-reservation-container">
      <h2>Update Reservation</h2>
      <form>
        <div>
          <label>Room Number:</label>
          <input
            type="text"
            name="roomNo"
            value={reservationData.roomNo}
            onChange={handleInputChange}
            readOnly
          />
          <span className="error">{validationErrors.roomNo}</span>
        </div>
        <div>
          <label>Guest ID:</label>
          <input
            type="text"
            name="guestId"
            value={reservationData.guestId}
            onChange={handleInputChange}
          />
          <span className="error">{validationErrors.guestId}</span>
        </div>
        <div>
          <label>Check-In Date:</label>
          <DatePicker
            selected={reservationData.checkInDate}
            onChange={(date) =>
              setReservationData({ ...reservationData, checkInDate: date })
            }
            name="checkInDate"
            minDate={new Date()}
            dateFormat="yyyy-MM-dd"
          />
          <span className="error">{validationErrors.checkInDate}</span>
        </div>
        <div>
          <label>Check-Out Date:</label>
          <DatePicker
            selected={reservationData.checkOutDate}
            onChange={(date) =>
              setReservationData({ ...reservationData, checkOutDate: date })
            }
            onBlur={calculateTotalPrice}
            name="checkOutDate"
            minDate={new Date()}
            dateFormat="yyyy-MM-dd"
          />
          <span className="error">{validationErrors.checkOutDate}</span>
        </div>
        <div>
          <label>Room Rent:</label>
          <input type="text" value={roomRent} readOnly />
        </div>
        <div>
          <label>Total Price:</label>
          <input
            type="text"
            name="totalPrice"
            value={reservationData.totalPrice}
            readOnly
          />
        </div>
        <button onClick={handleUpdateReservation}>Update Reservation</button>
      </form>
    </div>
  );
}

export default UpdateReservation;
